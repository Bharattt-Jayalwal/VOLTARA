import Link from "next/link";
import { CircleHelp } from "lucide-react";

export function ServiceUnavailable({ feature = "This feature" }: { feature?: string }) {
  if (feature === "Charger discovery") {
    return <main className="charger-source-fallback">
      <div className="eyebrow"><span className="eyebrow-line"/> REAL-WORLD CHARGER MAP</div>
      <div className="charger-source-heading">
        <div><h1>Find a charger near you.</h1><p>Search a place or use the map’s location control. These community-mapped locations are not live availability signals; confirm access and status with the charging provider before traveling.</p></div>
        <a className="button button-dark" href="https://map.openchargemap.io/" target="_blank" rel="noreferrer">Open full map ↗</a>
      </div>
      <iframe className="charger-source-frame" title="Open Charge Map community charger directory" src="https://map.openchargemap.io/?mode=embedded" allow="geolocation" loading="eager" referrerPolicy="strict-origin-when-cross-origin" />
      <p className="charger-source-attribution">Charger locations and map attribution are provided by <a href="https://openchargemap.org/" target="_blank" rel="noreferrer">Open Charge Map</a> and its contributors. Availability is not verified by VOLTARA.</p>
    </main>;
  }

  return <main className="not-found" role="status">
    <div className="eyebrow"><span className="eyebrow-line"/> VOLTARA SERVICE STATUS</div>
    <span className="service-unavailable-icon"><CircleHelp size={20}/></span>
    <h1>{feature} is temporarily unavailable.</h1>
    <p>This public environment needs a configured and reachable Supabase service. No sample chargers or browser-only account actions are being shown as live data.</p>
    <Link className="button button-lime" href="/">Return to VOLTARA</Link>
  </main>;
}
