"use client";

import Link from "next/link";
import { ArrowUpRight, Menu, Zap } from "lucide-react";
import { useState } from "react";
import { useStore } from "@/components/store";

export function Brand() { return <Link href="/" className="brand" aria-label="Voltara home"><span className="brand-mark"><Zap size={18} fill="currentColor" strokeWidth={2.5} /></span><span>VOLTARA</span></Link>; }

export function Header() {
  const [open, setOpen] = useState(false);
  const { user } = useStore();
  return <header className="site-header"><Brand /><button className="mobile-menu icon-button" aria-label="Toggle navigation" onClick={() => setOpen(!open)}><Menu size={20}/></button><nav className={open ? "nav-links is-open" : "nav-links"}>
    <Link href="/explore" onClick={() => setOpen(false)}>Explore</Link><Link href="/#how" onClick={() => setOpen(false)}>How it works</Link><Link href="/for-hosts" onClick={() => setOpen(false)}>For hosts</Link>
    <span className="nav-spacer" />{user ? <Link className="nav-account" href={user.role === "admin" ? "/admin" : user.role === "host" ? "/host" : "/dashboard"}>{user.displayName}<span className="role-dot" />Dashboard</Link> : <Link href="/login" className="nav-login">Sign in</Link>}
    <Link className="button button-lime header-cta" href="/explore">Find a charger <ArrowUpRight size={15}/></Link>
  </nav></header>;
}
