"use client";

import { useState } from "react";
import { ArrowRight, LoaderCircle } from "lucide-react";

export function ContactForm() {
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitting(true);
    setMessage("");
    setError("");
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form).entries());
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(values),
      });
      const body = await response.json();
      if (!response.ok) {
        setError(body.error || "We could not send your request. Please try again later.");
        return;
      }
      setMessage(body.message || "Your request was saved.");
      form.reset();
    } catch {
      setError("We could not reach the support service. Please try again later.");
    } finally {
      setSubmitting(false);
    }
  };

  return <form className="contact-form" onSubmit={submit}>
    <div className="contact-form-row">
      <label>Name<input name="name" autoComplete="name" minLength={2} maxLength={100} required/></label>
      <label>Email<input name="email" type="email" autoComplete="email" maxLength={254} required/></label>
    </div>
    <label>Inquiry category<select name="category" defaultValue="general" required>
      <option value="general">General question</option>
      <option value="charger_listing">Charger listing</option>
      <option value="booking_support">Booking support</option>
      <option value="account_privacy">Account or privacy</option>
      <option value="safety">Safety concern</option>
      <option value="other">Other</option>
    </select></label>
    <label>Subject<input name="subject" minLength={4} maxLength={160} required/></label>
    <label>Message<textarea name="message" minLength={10} maxLength={4000} rows={7} required/></label>
    <label className="contact-honeypot" aria-hidden="true">Website<input name="website" tabIndex={-1} autoComplete="off"/></label>
    <p className="contact-privacy">Please don’t include passwords, payment-card details, private access codes, or sensitive vehicle information.</p>
    {error && <div className="auth-error" role="alert">{error}</div>}
    {message && <div className="auth-status" role="status">{message}</div>}
    <button className="button button-lime contact-submit" type="submit" disabled={submitting}>
      {submitting ? <>Sending <LoaderCircle size={15} className="spin"/></> : <>Send message <ArrowRight size={15}/></>}
    </button>
  </form>;
}
