"use client";

import dynamic from "next/dynamic";
import Link from "next/link";
import { ArrowDownUp, ArrowRight, BatteryCharging, Bookmark, CalendarDays, Check, ChevronDown, CircleHelp, Clock3, LocateFixed, Map as MapIcon, Search, ShieldCheck, SlidersHorizontal, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { confidenceScore, formatChargePrice, freshnessLabel, type Charger } from "@/lib/chargers";
import { useStore, type Booking } from "@/components/store";
import { isSupabaseConfigured } from "@/lib/supabase-browser";
import { isDemoMode } from "@/lib/runtime-mode";
import { ServiceUnavailable } from "@/components/service-unavailable";

const ChargerMap = dynamic(() => import("@/components/map").then((m) => m.ChargerMap), { ssr: false, loading: () => <div className="map-loading"><span className="loader"/>Preparing the map…</div> });

export function ChargerCard({ charger, active, favorite, onClick, onFavorite }: { charger: Charger; active?: boolean; favorite?: boolean; onClick?: () => void; onFavorite?: () => void }) {
  const score = confidenceScore({ successfulSessions30d: charger.hostVerified ? 4 : 1, reports30d: 0, hostVerified: charger.hostVerified, lastConfirmedAt: charger.lastConfirmedAt });
  const statusLabel = charger.status === "available" ? charger.demo ? "Status recently confirmed · demo" : "Host reported available" : charger.status === "unavailable" ? charger.demo ? "Reported unavailable · demo" : "Host reported unavailable" : "Status unconfirmed";
  return <article className={`charger-card ${active ? "selected" : ""}`} onClick={onClick}>
    <div className="charger-card-top"><div className={`station-illustration ${charger.kind === "DC" ? "fast" : "slow"}`}><BatteryCharging size={25}/><span>{charger.kind}</span></div><span className={`status-pill ${charger.status}`}><i/>{charger.status === "available" ? "Recent signal" : charger.status === "unavailable" ? "Reported off" : "Unconfirmed"}</span></div>
    <div className="charger-card-title"><div><h3>{charger.name}</h3><p>{charger.area} <span>{charger.demo ? "· SIMULATED" : "· HOST LISTING"}</span></p></div><button className={`plain-icon ${favorite?"favorite-active":""}`} aria-label={favorite?"Remove saved charger":"Save charger"} aria-pressed={favorite} onClick={(event) => { event.stopPropagation(); onFavorite?.(); }}><Bookmark size={15} fill={favorite?"currentColor":"none"}/></button></div>
    <div className="charger-specs"><span><b>{charger.powerKw}</b> kW</span><span>{charger.kind} charge</span><span>{charger.connector}</span></div>
    <div className="charger-meta"><span><ShieldCheck size={14}/>{charger.hostVerified ? "Verified host" : "Not verified"}</span><span><Clock3 size={14}/>{freshnessLabel(charger.lastConfirmedAt)}</span></div>
    <div className="charger-card-bottom"><div><b>{formatChargePrice(charger.pricePerKwh, charger.currency)}</b><small>{charger.pricePerKwh === null ? "" : ` / kWh${charger.demo ? " · demo rate" : " · host listed"}`}</small></div><Link className="details-link" href={`/chargers/${charger.id}`} onClick={(event) => event.stopPropagation()}>Details <ArrowRight size={14}/></Link></div>
    <span className="sr-only">{statusLabel}{score ? `, confidence ${score} of 100, demo estimate` : ", confidence score unavailable due to insufficient evidence"}</span>
  </article>;
}

export function ExploreClient() {
  const { chargers, user, addBooking } = useStore();
  const [remoteChargers, setRemoteChargers] = useState<Charger[] | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [connector, setConnector] = useState("All connectors");
  const [charging, setCharging] = useState("Any power");
  const [selected, setSelected] = useState<string | null>(null);
  const [listOnly, setListOnly] = useState(false);
  const [userPoint, setUserPoint] = useState<[number, number] | null>(null);
  const [permissionMessage, setPermissionMessage] = useState("");
  const [bookingFor, setBookingFor] = useState<Charger | null>(null);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("17:00");
  const [duration, setDuration] = useState("2");
  const [message, setMessage] = useState("");
  useEffect(()=>{if(isDemoMode){queueMicrotask(()=>{try{setFavorites(JSON.parse(localStorage.getItem("voltara-demo-favorites")||"[]"));}catch{setFavorites([])}});return;}if(!isSupabaseConfigured)return;void Promise.all([fetch("/api/chargers").then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.error);setRemoteChargers((d.chargers||[]).map((c:Record<string,unknown>)=>({id:String(c.id),name:String(c.name),area:String(c.locality||"Host location"),latitude:Number(c.latitude),longitude:Number(c.longitude),powerKw:Number(c.power_kw),kind:c.charge_kind as Charger["kind"],connector:(((c.charger_connectors as {connector_type:string}[]|null)?.[0]?.connector_type||"Type 2") as Charger["connector"]),pricePerKwh:c.price_per_kwh==null?null:Number(c.price_per_kwh),currency:String(c.currency||""),access:c.access_type==="shared"?"Shared":"Public",hostVerified:Boolean(c.host_verified),listedBy:"Host-submitted",description:String(c.description||""),lastConfirmedAt:c.last_status_confirmed_at as string|null,status:(c.status as Charger["status"])||"unknown",demo:false})));}),fetch("/api/favorites").then(async r=>{if(r.ok){const d=await r.json();setFavorites((d.ids||[]) as string[]);}})]).catch(()=>setRemoteChargers([]));},[]);
  const stationSource = useMemo(() => isSupabaseConfigured ? (remoteChargers||[]) : isDemoMode ? chargers.filter(c=>!c.pending&&!c.paused) : [], [remoteChargers,chargers]);
  const visible = useMemo(() => stationSource.filter((c) => `${c.name} ${c.area} ${c.connector}`.toLowerCase().includes(query.toLowerCase()) && (connector === "All connectors" || c.connector === connector) && (charging === "Any power" || (charging === "DC fast" ? c.kind === "DC" : c.kind === "AC"))), [stationSource, query, connector, charging]);
  const chosen = visible.find((c) => c.id === selected);
  const locate = () => {
    if (!navigator.geolocation) { setPermissionMessage("This browser does not support location access."); return; }
    navigator.geolocation.getCurrentPosition((position) => { setUserPoint([position.coords.latitude, position.coords.longitude]); setPermissionMessage("Your location is shown on this device only."); }, () => setPermissionMessage("Location permission was not granted. You can still search the demo area."), { enableHighAccuracy: false, timeout: 8000 });
  };
  const toggleFavorite = async (id:string) => { const favorite=!favorites.includes(id);setFavorites(current=>favorite?[...current,id]:current.filter(x=>x!==id));if(isSupabaseConfigured){const response=await fetch("/api/favorites",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({chargerId:id,favorite})});if(!response.ok){setMessage("Sign in to save chargers to your account.");setFavorites(current=>favorite?current.filter(x=>x!==id):[...current,id]);}}else{const updated=favorite?[...favorites,id]:favorites.filter(x=>x!==id);localStorage.setItem("voltara-demo-favorites",JSON.stringify(updated));}};
  const submitBooking = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setMessage("");
    if (!user) { setMessage("Start a demo driver session or sign in before requesting a reservation."); return; }
    if (!date) { setMessage("Choose a date for your request."); return; }
    const startsAt = new Date(`${date}T${time}`);
    if (Number.isNaN(startsAt.getTime()) || startsAt <= new Date()) { setMessage("Choose a future date and time."); return; }
    const endsAt = new Date(startsAt.getTime() + Number(duration) * 3_600_000);
      const rule=chargers.find(c=>c.id===bookingFor!.id)?.availabilityRules;
      const localEnd=String(endsAt.getHours()).padStart(2,"0")+":"+String(endsAt.getMinutes()).padStart(2,"0");
      if(rule&&(!rule.weekdays.includes(startsAt.getDay())||time<rule.startTime||localEnd>rule.endTime)){setMessage("That request falls outside the host’s listed availability window.");return;}
    const booking: Booking = { id: crypto.randomUUID(), chargerId: bookingFor!.id, chargerName: bookingFor!.name, driverEmail: user.email, startsAt: startsAt.toISOString(), endsAt: endsAt.toISOString(), status: "pending", demo: true };
    if (isSupabaseConfigured) {
      const response = await fetch("/api/bookings", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ chargerId: booking.chargerId, startsAt: booking.startsAt, endsAt: booking.endsAt }) });
      const result = await response.json();
      if (!response.ok) { setMessage(result.error || "Could not request this booking."); return; }
      addBooking({ ...booking, id: result.id, demo: false });
      setMessage("Booking request sent to the host.");
    } else {
      if (chargers.find((c) => c.id === booking.chargerId)?.access === "Public") { setMessage("Public stations in this prototype are discovery only. Reservation is unavailable for this listing."); return; }
      const overlaps = JSON.parse(localStorage.getItem("voltara-demo-bookings") || "[]") as Booking[];
      if (overlaps.some((b) => b.chargerId === booking.chargerId && ["pending", "confirmed"].includes(b.status) && new Date(b.startsAt) < endsAt && new Date(b.endsAt) > startsAt)) { setMessage("That time overlaps an existing demo reservation."); return; }
      addBooking(booking); setMessage("Demo request saved. No real charger was reserved.");
    }
  };
  const openBooking = (charger: Charger) => { setBookingFor(charger); setDate(new Date(Date.now() + 24 * 60 * 60_000).toISOString().slice(0, 10)); setMessage(""); };
  if (!isSupabaseConfigured && !isDemoMode) return <ServiceUnavailable feature="Charger discovery"/>;
  return <div className="explore-shell">
    <div className="explore-head"><div><div className="eyebrow"><span className="eyebrow-line"/> FIND YOUR NEXT CHARGE</div><h1>Find a better<br className="small-only"/> place to plug in.</h1><p>Compare connector fit, host access, and status freshness before you set off.</p></div><div className="demo-notice"><i/> {isSupabaseConfigured?"CONNECTED LISTINGS":"DEMO DATA"} <span>{isSupabaseConfigured?"Approved database records":"Fictional stations · no live network connection"}</span></div></div>
    <section className={`discovery-layout ${listOnly ? "show-map" : ""}`}>
      <div className="results-panel"><div className="search-row"><div className="search-input"><Search size={17}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search area or connector" aria-label="Search chargers"/><button aria-label="Filter options" onClick={() => document.getElementById("connector-filter")?.focus()}><SlidersHorizontal size={16}/></button></div><button className="sort-button" onClick={() => setCharging(charging === "DC fast" ? "Any power" : "DC fast")}><ArrowDownUp size={15}/> {charging === "DC fast" ? "Fastest" : "Filter"}<ChevronDown size={14}/></button></div>
      <div className="filters-row"><label><span className="sr-only">Connector type</span><select id="connector-filter" value={connector} onChange={(e) => setConnector(e.target.value)}><option>All connectors</option>{["NACS", "CCS2", "Type 2", "CHAdeMO"].map((x) => <option key={x}>{x}</option>)}</select></label><label><span className="sr-only">Charging type</span><select value={charging} onChange={(e) => setCharging(e.target.value)}><option>Any power</option><option>DC fast</option><option>AC only</option></select></label><span className="result-count">{visible.length} demo stations</span></div>
      <div className="results-scroll">{remoteChargers===null&&isSupabaseConfigured?<div className="empty-state"><span className="loader"/><b>Loading approved listings</b><span>Waiting for the configured Supabase project.</span></div>:visible.length ? visible.map((charger) => <ChargerCard key={charger.id} charger={charger} active={selected === charger.id} favorite={favorites.includes(charger.id)} onFavorite={()=>void toggleFavorite(charger.id)} onClick={() => { setSelected(charger.id); setListOnly(true); }}/>) : <div className="empty-state"><CircleHelp/><b>{isSupabaseConfigured?"No approved listings yet":"No matching demo chargers"}</b><span>{isSupabaseConfigured?"Verified host listings will appear here after admin approval.":"Try a different connector or search term."}</span></div>}</div>
      </div>
      <div className={`map-panel ${listOnly ? "map-hidden" : ""}`}><div className="map-toolbar"><div className="map-location-label"><MapIcon size={15}/><span>{isSupabaseConfigured?"Approved charger locations":"Brooklyn Demo Loop"} <small>{isSupabaseConfigured?"Database records · no routing ETA":"Simulated area · US coordinates for map preview"}</small></span></div><div className="map-tools"><button className="plain-icon" onClick={locate} aria-label="Use my location" title="Use my location"><LocateFixed size={17}/></button><button className="button button-dark map-mobile-toggle" onClick={() => setListOnly(false)}>View list</button></div></div>
      <ChargerMap chargers={visible} selectedId={selected} onSelect={(charger) => setSelected(charger.id)} userPoint={userPoint}/>
      <div className="map-bottom-card">{chosen ? <><div className="map-card-title"><span className="map-card-icon"><BatteryCharging size={17}/></span><span><b>{chosen.name}</b><small>{chosen.connector} · {chosen.powerKw} kW · SIMULATED</small></span><button className="plain-icon" onClick={() => setSelected(null)} aria-label="Close selected station"><X size={16}/></button></div><p>{chosen.status === "available" ? "Recent host confirmation · verify directly before travel" : "Current operating status has not been confirmed"}</p><div className="map-card-actions"><Link href={`/chargers/${chosen.id}`} className="button button-dark">View details</Link>{chosen.access === "Shared" && <button className="button button-lime" onClick={() => openBooking(chosen)}>Request a slot</button>}</div></> : <div className="map-card-prompt"><span className="mini-spark">✳</span><span><b>Select a charger to see details</b><small>Pin status is simulated for this demo</small></span></div>}</div>
      </div>
      <div className="mobile-list-toggle"><button className="button button-dark" onClick={() => setListOnly(!listOnly)}>{listOnly ? "View list" : "Show map"}</button></div>
    </section>
    {permissionMessage && <div className="toast-message" role="status">{permissionMessage}</div>}
    {bookingFor && <div className="modal-backdrop" onClick={() => setBookingFor(null)}><section className="booking-modal" role="dialog" aria-modal="true" aria-labelledby="booking-title" onClick={(e) => e.stopPropagation()}><button className="modal-close plain-icon" onClick={() => setBookingFor(null)} aria-label="Close"><X/></button><div className="eyebrow"><span className="eyebrow-line"/> DEMO BOOKING REQUEST</div><h2 id="booking-title">Request a charging slot</h2><p className="modal-subtitle">{bookingFor.name} · host approval required. Demo requests do not reserve a real charger.</p><form onSubmit={submitBooking} className="booking-form"><label>Day<input type="date" min={new Date().toISOString().slice(0,10)} value={date} onChange={(e) => setDate(e.target.value)}/></label><label>Start time<input type="time" value={time} onChange={(e) => setTime(e.target.value)}/></label><label>Duration<select value={duration} onChange={(e) => setDuration(e.target.value)}><option value="1">1 hour</option><option value="2">2 hours</option><option value="3">3 hours</option><option value="4">4 hours</option></select></label><div className="payment-demo"><span className="payment-icon">$</span><span><b>Demo — no payment collected</b><small>Estimated energy cost only. Final cost may vary.</small></span><Check size={16}/></div>{message && <div className="form-message" role="status">{message}</div>}<button className="button button-lime submit-button" type="submit"><CalendarDays size={16}/> Send request <ArrowRight size={16}/></button></form></section></div>}
    <div className="distance-hint">Distance is available only after you share location. Navigation uses your device’s map app.</div>
  </div>;
}
