"use client";

import Link from "next/link";
import { ArrowLeft, ArrowRight, CircleHelp, ShieldCheck, Zap } from "lucide-react";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient, isSupabaseConfigured } from "@/lib/supabase-browser";
import { isDemoMode } from "@/lib/runtime-mode";
import { useStore } from "@/components/store";

export function AuthForm({ mode }: { mode: "login" | "signup" | "reset" }) {
  const { setUser } = useStore();
  const router = useRouter();
  const params = useSearchParams();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState("");
  const [error, setError] = useState(() => params.get("error") ? "That sign-in link expired or could not be verified. Request a new link and try again." : "");
  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setStatus(""); setError("");
    try {
      if (isSupabaseConfigured) {
        const supabase = createClient();
        if (mode === "signup") {
          const { error: authError } = await supabase.auth.signUp({ email, password, options: { data: { display_name: name }, emailRedirectTo: `${window.location.origin}/auth/callback?next=/dashboard` } });
          if (authError) throw authError;
          setStatus("Check your inbox to verify your email, then sign in.");
        } else if (mode === "reset") {
          const { error: authError } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/auth/callback?next=/reset-password` });
          if (authError) throw authError;
          setStatus("If this email is registered, a reset link is on its way.");
        } else {
          const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password });
          if (authError) throw authError;
          const [{ data: rows }, { data: profile }] = await Promise.all([
            supabase.from("user_roles").select("role").eq("user_id", data.user.id),
            supabase.from("profiles").select("display_name,phone").eq("id", data.user.id).maybeSingle(),
          ]);
          const role = rows?.some((r) => r.role === "admin") ? "admin" : rows?.some((r) => r.role === "host") ? "host" : "driver";
          setUser({ id: data.user.id, email: data.user.email || email, displayName: profile?.display_name || data.user.user_metadata.display_name || email.split("@")[0], phone: profile?.phone || undefined, role });
          router.push(role === "admin" ? "/admin" : role === "host" ? "/host" : params.get("next") || "/dashboard");
        }
      } else if (isDemoMode) {
        if (mode === "reset") { setStatus("Demo mode has no password account. Configure Supabase to enable password reset."); return; }
        const demoName = mode === "signup" ? name.trim() : (name.trim() || email.split("@")[0] || "Demo Driver");
        if (!email.includes("@")) { setError("Enter a valid email address."); return; }
        setUser({ id: `demo-${email.toLowerCase()}`, email, displayName: demoName, role: "driver" });
        router.push("/dashboard");
      } else {
        setError("Account service is temporarily unavailable. Please try again later.");
      }
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Something went wrong. Please try again."); }
  };
  const title = mode === "signup" ? "Create your account" : mode === "reset" ? "Reset your password" : "Welcome back";
  return <main className="auth-shell"><div className="auth-backdrop"/><section className="auth-card"><Link href="/" className="auth-brand"><span className="brand-mark"><Zap size={17} fill="currentColor"/></span> VOLTARA</Link><div className="eyebrow"><span className="eyebrow-line"/> YOUR CHARGING, WITH CLARITY</div><h1>{title}</h1><p className="auth-intro">{mode === "signup" ? "Save vehicles, request shared charging, and keep your plans in one place." : mode === "reset" ? "Enter your account email and we’ll send a password reset link." : "Sign in to manage your vehicles, reservations, and saved chargers."}</p>
  <form className="auth-form" onSubmit={submit}>
    {mode === "signup" && <label>Name<input required autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name"/></label>}
    <label>Email address<input required type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"/></label>
    {mode !== "reset" && isSupabaseConfigured && <label>Password<input required type="password" minLength={8} autoComplete={mode === "signup" ? "new-password" : "current-password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 8 characters"/></label>}
    {mode === "login" && isSupabaseConfigured && <Link className="forgot-link" href="/forgot-password">Forgot password?</Link>}
    {error && <div className="auth-error" role="alert">{error}</div>}{status && <div className="auth-status" role="status">{status}</div>}
    <button className="button button-lime auth-submit" type="submit" disabled={!isSupabaseConfigured && !isDemoMode}>{!isSupabaseConfigured && !isDemoMode ? "Account service unavailable" : mode === "signup" ? "Create account" : mode === "reset" ? "Send reset link" : isSupabaseConfigured ? "Sign in" : "Continue as demo driver"}<ArrowRight size={16}/></button>
  </form>
  {isDemoMode && mode !== "reset" && <div className="auth-demo-note"><CircleHelp size={16}/><span><b>Demo environment</b><small>No password is collected in demo mode. Your demo profile is saved in this browser only.</small></span></div>}
  {!isSupabaseConfigured && !isDemoMode && <div className="auth-error" role="status">Account services are not configured for this production environment.</div>}
  {isSupabaseConfigured && <div className="auth-security"><ShieldCheck size={14}/> Email verification and Supabase session cookies are enabled.</div>}
  <div className="auth-switch">{mode === "signup" ? <>Already have an account? <Link href="/login">Sign in</Link></> : mode === "reset" ? <>Remembered it? <Link href="/login">Sign in</Link></> : <>New to VOLTARA? <Link href="/signup">Create an account</Link></>}</div>
  <Link href="/" className="auth-return"><ArrowLeft size={13}/> Back to home</Link></section><aside className="auth-side"><div className="auth-side-signal"><span/><span/><span/></div><div className="eyebrow"><span className="eyebrow-line"/> TRUST, BUILT INTO THE JOURNEY</div><h2>Know before<br/>you <span>go.</span></h2><p>Every charger detail should tell you what’s compatible, what’s confirmed, and when it was last checked.</p><div className="auth-side-list"><span><ShieldCheck size={15}/> Verified host access</span><span><Zap size={15}/> Connector fit details</span><span><CircleHelp size={15}/> Clear uncertainty labels</span></div><small>Demonstration environment · no live charging network</small></aside></main>;
}
