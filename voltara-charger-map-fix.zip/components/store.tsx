"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { Charger } from "@/lib/chargers";
import { demoChargers } from "@/lib/chargers";
import { isSupabaseConfigured, createClient } from "@/lib/supabase-browser";
import { isDemoMode } from "@/lib/runtime-mode";

export type DemoUser = { id: string; email: string; displayName: string; role: "driver" | "host" | "admin"; phone?: string };
export type Booking = { id: string; chargerId: string; chargerName: string; driverEmail: string; startsAt: string; endsAt: string; status: "pending" | "confirmed" | "rejected" | "cancelled" | "completed" | "failed"; demo: boolean };
type Store = {
  user: DemoUser | null;
  chargers: Charger[];
  bookings: Booking[];
  setUser: (user: DemoUser | null) => void;
  setRole: (role: DemoUser["role"]) => void;
  addBooking: (booking: Booking) => void;
  updateBooking: (id: string, status: Booking["status"]) => void;
  addCharger: (charger: Charger) => void;
  reviewCharger: (id: string, approved: boolean) => void;
};

const StoreContext = createContext<Store | null>(null);
const read = <T,>(key: string, fallback: T): T => { try { const value = localStorage.getItem(key); return value ? JSON.parse(value) as T : fallback; } catch { return fallback; } };

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [user, setUserState] = useState<DemoUser | null>(null);
  const [chargers, setChargers] = useState<Charger[]>(isDemoMode ? demoChargers : []);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    queueMicrotask(() => {
      if (isSupabaseConfigured) {
        setUserState(null);
      } else if (isDemoMode) {
        setUserState(read("voltara-demo-user", null));
        setChargers(read("voltara-demo-chargers", demoChargers));
        setBookings(read("voltara-demo-bookings", []));
      } else {
        setUserState(null);
        setChargers([]);
        setBookings([]);
      }
      setReady(true);
    });
    if (isSupabaseConfigured) {
      const supabase = createClient();
      void supabase.auth.getUser().then(async ({ data }) => {
        if (!data.user) return;
        const [{ data: rows }, { data: profile }] = await Promise.all([
          supabase.from("user_roles").select("role").eq("user_id", data.user.id),
          supabase.from("profiles").select("display_name,phone").eq("id", data.user.id).maybeSingle(),
        ]);
        const role = rows?.some((r) => r.role === "admin") ? "admin" : rows?.some((r) => r.role === "host") ? "host" : "driver";
        setUserState({ id: data.user.id, email: data.user.email || "", displayName: profile?.display_name || data.user.user_metadata.display_name || data.user.email?.split("@")[0] || "Driver", phone: profile?.phone || undefined, role });
      });
    }
  }, []);
  useEffect(() => { if (ready && isDemoMode) localStorage.setItem("voltara-demo-user", JSON.stringify(user)); }, [user, ready]);
  useEffect(() => { if (ready && isDemoMode) localStorage.setItem("voltara-demo-chargers", JSON.stringify(chargers.filter(c=>c.demo))); }, [chargers, ready]);
  useEffect(() => { if (ready && isDemoMode) localStorage.setItem("voltara-demo-bookings", JSON.stringify(bookings.filter(b=>b.demo))); }, [bookings, ready]);
  const setUser = useCallback((v: DemoUser | null) => setUserState(v), []);
  const setRole = useCallback((role: DemoUser["role"]) => { if (isDemoMode) setUserState((u) => u ? { ...u, role } : { id: "demo-driver", email: "driver@voltara.demo", displayName: "Demo Driver", role }); }, []);
  const addBooking = useCallback((v: Booking) => setBookings((items) => [v, ...items]), []);
  const updateBooking = useCallback((id: string, status: Booking["status"]) => setBookings((items) => items.map((b) => b.id === id ? { ...b, status } : b)), []);
  const addCharger = useCallback((v: Charger) => setChargers((items) => [v, ...items]), []);
  const reviewCharger = useCallback((id: string, approved: boolean) => setChargers((items) => items.map((c) => c.id === id ? { ...c, pending: !approved, status: "unknown" } : c)), []);
  const value = useMemo(() => ({ user, chargers, bookings, setUser, setRole, addBooking, updateBooking, addCharger, reviewCharger }), [user, chargers, bookings, setUser, setRole, addBooking, updateBooking, addCharger, reviewCharger]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() { const context = useContext(StoreContext); if (!context) throw new Error("useStore must be used within StoreProvider"); return context; }
