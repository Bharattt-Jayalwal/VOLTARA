"use client";

import { CircleMarker, MapContainer, Popup, TileLayer, useMap } from "react-leaflet";
import { useEffect, useState } from "react";
import type { Charger } from "@/lib/chargers";
import "leaflet/dist/leaflet.css";

function Focus({ point }: { point: [number, number] | null }) { const map = useMap(); useEffect(()=>{if(point)map.flyTo(point,14,{duration:.65});},[map,point]); return null; }

export function ChargerMap({ chargers, selectedId, onSelect, userPoint }: { chargers: Charger[]; selectedId: string | null; onSelect: (charger: Charger) => void; userPoint: [number, number] | null }) {
  const selected = chargers.find((c) => c.id === selectedId);
  const [tileError,setTileError]=useState(false);
  const first=chargers[0];
  const focus: [number,number] | null = selected ? [selected.latitude,selected.longitude] : userPoint || (first ? [first.latitude,first.longitude] : null);
  const initial:[number,number]=first?[first.latitude,first.longitude]:[40.7132,-73.9895];
  return <div className="map-wrap"><MapContainer center={initial} zoom={13} scrollWheelZoom className="leaflet-map" aria-label="Interactive charger discovery map">
    <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url={process.env.NEXT_PUBLIC_MAP_TILE_URL || "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"} eventHandlers={{tileerror:()=>setTileError(true),load:()=>setTileError(false)}}/>
    <Focus point={focus}/>
    {chargers.map((charger) => <CircleMarker key={charger.id} center={[charger.latitude, charger.longitude]} radius={charger.id === selectedId ? 12 : 9} pathOptions={{ color: charger.status === "available" ? "#172114" : "#f5f5f1", weight: 3, fillColor: charger.status === "available" ? "#b8ff3b" : "#68756e", fillOpacity: 1 }} eventHandlers={{ click: () => onSelect(charger) }}>
      <Popup><div className="map-popup"><b>{charger.name}</b><span>{charger.kind} · {charger.powerKw} kW · {charger.connector}</span><small>{charger.demo?"SIMULATED DEMO STATION":"APPROVED HOST LISTING"}</small><button onClick={() => onSelect(charger)}>View details</button></div></Popup>
    </CircleMarker>)}
    {userPoint && <CircleMarker center={userPoint} radius={7} pathOptions={{ color: "white", fillColor: "#2c7dff", fillOpacity: 1, weight: 3 }}><Popup>Your shared location</Popup></CircleMarker>}
    </MapContainer>{tileError&&<div className="tile-error" role="status">Map tiles could not be loaded. Charger results are still available in the list.</div>}<span className="map-sim-label"><span className="pulse-dot"/> {chargers.some(c=>!c.demo)?"DATABASE LISTINGS":"SIMULATED DEMO AREA"}</span><div className="map-attribution-note">Map tiles © OpenStreetMap contributors{chargers.some(c=>c.demo)?" · Demo pins are fictional":""}</div></div>;
}
