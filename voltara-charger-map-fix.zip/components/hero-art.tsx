import { isDemoMode, isSupabaseConfigured } from "@/lib/runtime-mode";

export function HeroArt() {
  return <div className="hero-art" aria-label="Illustration of an electric vehicle beside a charging station">
    <div className="art-grid"/><div className="art-halo art-halo-one"/><div className="art-halo art-halo-two"/>
    <div className="art-orb"><span>01</span></div>
    <svg className="ev-scene" viewBox="0 0 920 420" role="img" aria-label="Electric car charging beside a luminous station">
      <defs>
        <linearGradient id="carBody" x1="0" x2="1" y1="0" y2="1"><stop stopColor="#eef5ef"/><stop offset=".4" stopColor="#82938a"/><stop offset="1" stopColor="#27342e"/></linearGradient>
        <linearGradient id="glass" x1="0" x2="1"><stop stopColor="#17251f"/><stop offset="1" stopColor="#293c35"/></linearGradient>
        <linearGradient id="floor" x1="0" x2="0" y1="0" y2="1"><stop stopColor="#b8ff3b" stopOpacity=".42"/><stop offset="1" stopColor="#b8ff3b" stopOpacity="0"/></linearGradient>
        <filter id="glow"><feGaussianBlur stdDeviation="8" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      </defs>
      <ellipse cx="457" cy="355" rx="377" ry="44" fill="url(#floor)" opacity=".65"/>
      <path d="M135 292c18-52 60-93 125-121l92-41c29-14 72-21 115-21h106c35 0 66 14 87 40l66 82 39 18c20 10 32 31 32 54v34H116v-20c0-12 6-20 19-25z" fill="url(#carBody)" stroke="#e3eee6" strokeOpacity=".8" strokeWidth="2"/>
      <path d="m290 163 77-34c27-12 63-19 100-19h94c27 0 49 11 67 33l50 62H251c10-16 23-30 39-42z" fill="url(#glass)" stroke="#9caea3" strokeOpacity=".38"/>
      <path d="m469 110-1 95m102-95 5 95" stroke="#93a69b" strokeOpacity=".4"/>
      <path d="M179 285h35m541-26h44" stroke="#b8ff3b" strokeWidth="7" strokeLinecap="round" filter="url(#glow)"/>
      <path d="M119 321h678" stroke="#b8ff3b" strokeOpacity=".35" strokeWidth="2"/>
      <path d="M217 324a47 47 0 1 0 94 0" fill="#111815" stroke="#47544c" strokeWidth="8"/><circle cx="264" cy="324" r="21" fill="#25332c" stroke="#95a69b" strokeWidth="4"/><path d="M612 324a47 47 0 1 0 94 0" fill="#111815" stroke="#47544c" strokeWidth="8"/><circle cx="659" cy="324" r="21" fill="#25332c" stroke="#95a69b" strokeWidth="4"/>
      <g transform="translate(748 100)"><rect x="0" y="0" width="75" height="200" rx="20" fill="#202b25" stroke="#89998e" strokeOpacity=".65"/><rect x="13" y="20" width="49" height="60" rx="8" fill="#0e1712" stroke="#607567"/><path d="M38 32 27 54h11l-5 15 18-26H39l8-11z" fill="#b8ff3b" filter="url(#glow)"/><circle cx="37" cy="106" r="6" fill="#b8ff3b"/><path d="M38 114c0 49 24 41 24 57v24" fill="none" stroke="#b8ff3b" strokeWidth="5" strokeLinecap="round"/><path d="M62 195q9 0 9 9v8" fill="none" stroke="#d8e3dc" strokeWidth="4"/></g>
      <path d="M773 301v20c0 30-22 42-55 42H581" fill="none" stroke="#b8ff3b" strokeWidth="2" strokeDasharray="3 9" opacity=".8"/>
    </svg>
    <div className="art-chip chip-top"><i/> {isDemoMode ? "LOCAL DEMO ENVIRONMENT" : isSupabaseConfigured ? "HOST-LISTED DIRECTORY" : "DIRECTORY UNAVAILABLE"}</div>
    <div className="art-chip chip-bottom"><span className="chip-icon">↗</span><span><b>Trust starts with transparency</b><small>{isDemoMode ? "Demo stations are simulated" : "Status is not live charger telemetry"}</small></span></div>
    <div className="art-caption">VOL 01 / CHARGE WITH CONFIDENCE</div>
  </div>;
}
