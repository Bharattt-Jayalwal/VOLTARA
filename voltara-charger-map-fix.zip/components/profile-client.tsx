"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, Check, UserRound } from "lucide-react";
import { useStore } from "@/components/store";
import { isSupabaseConfigured } from "@/lib/supabase-browser";
import { isDemoMode } from "@/lib/runtime-mode";
import { ServiceUnavailable } from "@/components/service-unavailable";

export function ProfileClient() {
  const { user, setUser } = useStore();
  const [name, setName] = useState<string | null>(null);
  const [phone, setPhone] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const userId = user?.id;
  const userName = user?.displayName;

  useEffect(() => {
    if (!isSupabaseConfigured || !userId) return;
    void fetch("/api/profile").then(async (response) => {
      const body = await response.json();
      if (response.ok) {
        setName(body.displayName || userName || "");
        setPhone(body.phone || "");
      }
    });
  }, [userId, userName]);

  const save = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setNotice("");
    setError("");
    if (!user) {
      setError("Sign in before editing your profile.");
      return;
    }
    const displayName = (name ?? user.displayName).trim();
    const phoneNumber = (phone ?? user.phone ?? "").trim();
    if (displayName.length < 2 || displayName.length > 80) {
      setError("Enter a display name between 2 and 80 characters.");
      return;
    }

    if (isSupabaseConfigured) {
      const response = await fetch("/api/profile", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ displayName, phone: phoneNumber || null }),
      });
      const body = await response.json();
      if (!response.ok) {
        setError(body.error || "Could not save profile details.");
        return;
      }
    }

    setUser({ ...user, displayName, phone: phoneNumber || undefined });
    setName(displayName);
    setPhone(phoneNumber);
    setNotice(isSupabaseConfigured ? "Profile saved to your account." : "Profile saved in this browser.");
  };

  if (!isSupabaseConfigured && !isDemoMode) return <ServiceUnavailable feature="Profile settings"/>;
  return <main className="dashboard-shell"><Link href="/dashboard" className="back-link"><ArrowLeft size={14}/> Driver dashboard</Link><div className="dashboard-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> PROFILE SETTINGS</div><h1>Your details.</h1><p>Keep your display name and optional contact number up to date.</p></div></div>
    <div className="demo-banner"><UserRound size={16}/><span><b>{isSupabaseConfigured ? "Connected account" : "Browser demo"}</b> {isSupabaseConfigured ? "Changes are saved to your authenticated profile." : "Profile details remain in this browser and are not used to verify charger access."}</span></div>
    {!user ? <section className="dashboard-main-card"><b>Sign in to view profile settings.</b><p>Your profile details appear here after you sign in.</p><Link className="button button-lime" href="/login">Sign in <ArrowRight size={15}/></Link></section> : <section className="dashboard-main-card profile-card"><div className="panel-title"><span><UserRound size={17}/> Personal details</span><span className="panel-count">{user.email}</span></div><form className="vehicle-form" onSubmit={save}><label>Display name<input required minLength={2} maxLength={80} value={name ?? user.displayName} onChange={(event) => setName(event.target.value)} autoComplete="name"/></label><label>Phone number <small>(optional)</small><input type="tel" maxLength={32} value={phone ?? user.phone ?? ""} onChange={(event) => setPhone(event.target.value)} autoComplete="tel" placeholder="Add a contact number"/></label><small>Providing a phone number does not verify the number or grant charger access.</small>{error && <div className="form-message" role="alert">{error}</div>}{notice && <div className="form-message" role="status"><Check size={14}/>{notice}</div>}<button className="button button-lime" type="submit">Save profile <ArrowRight size={15}/></button></form></section>}
  </main>;
}
