import { redirect } from "next/navigation";
export default function AdminChargersPage(){redirect("/admin");}
