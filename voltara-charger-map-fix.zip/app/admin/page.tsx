import { AdminClient } from "@/components/admin-client";
export const metadata={title:"Admin verification · VOLTARA"};
export default function AdminPage(){return <AdminClient/>;}
