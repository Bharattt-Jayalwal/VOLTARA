import { Suspense } from "react";
import { AuthForm } from "@/components/auth-form";
export const metadata={title:"Reset password · VOLTARA"};
export default function ForgotPasswordPage(){return <Suspense fallback={<main className="auth-loading">Loading password reset…</main>}><AuthForm mode="reset"/></Suspense>;}
