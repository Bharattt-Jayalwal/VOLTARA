import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  let origin: string;
  try {
    const configured = process.env.NEXT_PUBLIC_SITE_URL;
    if (!configured) return [];
    origin = new URL(configured).origin;
  } catch {
    return [];
  }

  const lastModified = new Date();
  return ["/", "/about", "/how-it-works", "/for-hosts", "/contact"].map((path) => ({
    url: new URL(path, origin).toString(),
    lastModified,
    changeFrequency: path === "/" ? "weekly" : "monthly",
    priority: path === "/" ? 1 : 0.6,
  }));
}
