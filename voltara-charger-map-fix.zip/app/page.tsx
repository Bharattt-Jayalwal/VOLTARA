import Link from "next/link";
import { ArrowRight, ArrowUpRight, Check, CircleHelp, Clock3, Compass, ShieldCheck, WalletCards, Zap } from "lucide-react";
import { HeroArt } from "@/components/hero-art";
import { demoChargers, type Charger } from "@/lib/chargers";
import { createClient } from "@/lib/supabase-server";
import { isDemoMode } from "@/lib/runtime-mode";

type HomeCharger = Omit<Charger, "pricePerKwh"> & { currency: string; pricePerKwh: number | null };

export default async function HomePage() {
  let previewChargers: HomeCharger[] = [];
  let directoryUnavailable = false;

  if (isDemoMode) {
    previewChargers = demoChargers.slice(0, 3).map((charger) => ({ ...charger, currency: "USD" }));
  } else {
    const supabase = await createClient();
    if (!supabase) {
      directoryUnavailable = true;
    } else {
      const { data, error } = await supabase
        .from("chargers")
        .select("id,name,description,locality,latitude,longitude,power_kw,charge_kind,access_type,host_verified,status,last_status_confirmed_at,price_per_kwh,currency,charger_connectors(connector_type)")
        .eq("listing_status", "approved")
        .eq("is_listed", true)
        .eq("demo", false)
        .order("created_at", { ascending: false })
        .limit(3);

      if (error) {
        directoryUnavailable = true;
      } else {
        previewChargers = (data ?? []).map((row) => ({
          id: row.id,
          name: row.name,
          area: row.locality || "Host supplied location",
          latitude: row.latitude,
          longitude: row.longitude,
          powerKw: Number(row.power_kw),
          kind: row.charge_kind as Charger["kind"],
          connector: ((row.charger_connectors as { connector_type: string }[] | null)?.[0]?.connector_type || "Other") as Charger["connector"],
          pricePerKwh: row.price_per_kwh === null ? null : Number(row.price_per_kwh),
          currency: row.currency?.trim() || "",
          access: row.access_type === "shared" ? "Shared" : "Public",
          hostVerified: Boolean(row.host_verified),
          listedBy: "Host submitted",
          description: row.description || "",
          lastConfirmedAt: row.last_status_confirmed_at,
          status: (row.status || "unknown") as Charger["status"],
          demo: false,
        }));
      }
    }
  }

  return <main className="home-page">
    <section className="hero-section"><div className="hero-copy"><div className="eyebrow"><span className="eyebrow-line"/> RELIABILITY FIRST EV CHARGING</div><h1>Charging should<br/>never be a <span>guess.</span></h1><p>Discover compatible EV chargers, book private charging spaces, and know what’s confirmed before you head out.</p><div className="hero-actions"><Link href="/explore" className="button button-lime">Explore chargers <ArrowUpRight size={17}/></Link><Link href="/host" className="text-link">List your charger <ArrowRight size={16}/></Link></div><div className="hero-proof"><span><i><Check size={11}/></i> Compatibility first</span><span><i><Check size={11}/></i> Freshness explained</span><span><i><Check size={11}/></i> Host access verified</span></div></div><HeroArt/><div className="hero-scroll"><span/> SCROLL TO EXPLORE</div></section>
    <section className="trust-section" id="how"><div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> THE VOLTARA DIFFERENCE</div><h2>Know before<br/>you go.</h2></div><p>Finding a plug is only half the journey. We bring the details that help you decide with more confidence.</p></div><div className="trust-grid"><article><span className="feature-icon"><Zap size={19}/></span><span className="feature-index">01 / FIT</span><h3>Connector compatibility</h3><p>See connector types and charging speeds up front, so your next stop fits your vehicle.</p></article><article><span className="feature-icon"><Clock3 size={19}/></span><span className="feature-index">02 / FRESHNESS</span><h3>Status with a timestamp</h3><p>Check when a station was last confirmed. We don’t disguise old information as live status.</p></article><article><span className="feature-icon"><ShieldCheck size={19}/></span><span className="feature-index">03 / ACCESS</span><h3>Verified host details</h3><p>Understand whether a charger is public or shared, and who reviews private host listings.</p></article><article><span className="feature-icon"><Compass size={19}/></span><span className="feature-index">04 / BACKUP</span><h3>A clearer next option</h3><p>When a plan changes, find a compatible alternative and open directions from your device.</p></article></div></section>
    <section className="how-section"><div className="eyebrow"><span className="eyebrow-line"/> A BETTER WAY TO CHARGE</div><div className="how-grid"><h2>Simple from<br/>search to charge.</h2><div className="how-steps"><div><span>01</span><div><b>Find a compatible charger</b><p>Filter by connector and charging speed.</p></div></div><div><span>02</span><div><b>Check the details</b><p>Review access, price, verification and status freshness.</p></div></div><div><span>03</span><div><b>Reserve a shared slot</b><p>Send a request to the host and wait for confirmation.</p></div></div></div></div></section>
    <section className="preview-section"><div className="section-heading preview-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> A LOOK INSIDE</div><h2>Find your next<br/>charging stop.</h2></div><Link href="/explore" className="text-link">{isDemoMode ? "Explore demo map" : "Explore listings"} <ArrowRight size={16}/></Link></div>
      {previewChargers.length > 0 ? <div className="preview-grid">{previewChargers.map((charger, index) => <article key={charger.id} className="preview-card"><div className={`preview-art preview-art-${index+1}`}><span>{charger.kind} / {charger.powerKw} kW</span><div className="preview-sun"/><div className="preview-horizon"/><div className="preview-charge"><Zap size={18}/></div></div><div className="preview-card-body"><div className="preview-label">{charger.demo ? "SIMULATED STATION" : "HOST SUBMITTED"}<span>{charger.demo ? charger.status === "available" ? "STATUS RECENTLY CONFIRMED" : "STATUS UNCONFIRMED" : charger.status === "unavailable" ? "HOST REPORTED UNAVAILABLE" : charger.status === "available" ? "HOST REPORTED AVAILABLE" : "STATUS UNCONFIRMED"}</span></div><h3>{charger.name}</h3><p>{charger.area} · {charger.connector}</p><div className="preview-card-bottom"><b>{charger.pricePerKwh === null ? "Price not listed" : `${charger.currency} ${charger.pricePerKwh.toFixed(2)}`} <small>{charger.pricePerKwh === null ? "" : "/ kWh"}</small></b><Link aria-label={`View ${charger.name}`} href={`/chargers/${charger.id}`}><ArrowUpRight size={17}/></Link></div></div></article>)}</div> : <div className="empty-state"><CircleHelp/><b>{directoryUnavailable ? "Charger directory is temporarily unavailable" : "No approved chargers yet"}</b><span>{directoryUnavailable ? "The directory needs a configured and reachable database. Please try again later." : "Approved host-submitted listings will appear here."}</span></div>}
      {isDemoMode && <div className="demo-disclaimer"><CircleHelp size={14}/> These listings are simulated demonstration content and do not represent real charger availability or physical stations.</div>}
    </section>
    <section className="host-banner"><div className="host-banner-orbit"/><div className="host-banner-copy"><div className="eyebrow"><span className="eyebrow-line"/> FOR CHARGER HOSTS</div><h2>Your charger<br/>can do <span>more.</span></h2><p>Share eligible charging capacity, set your availability and review each request before you accept.</p><Link className="button button-lime" href="/host">Become a host <ArrowUpRight size={16}/></Link></div><div className="host-banner-card"><span className="host-card-top"><span className="host-card-symbol"><WalletCards size={18}/></span><span>HOST OVERVIEW <i>{isDemoMode ? "DEMO" : "PREVIEW"}</i></span><span className="host-card-more">•••</span></span><div className="host-card-label">Estimated gross booking value</div><div className="host-card-value">$— <small>Not available</small></div><div className="host-card-note"><span>◉</span> Values appear only when real payment records exist</div><div className="host-card-lines"><span/><span/><span/></div></div></section>
    <section className="final-cta"><div className="eyebrow"><span className="eyebrow-line"/> EVERY CHARGE, A LITTLE CLEARER</div><h2>Make every charge<br/><span>count.</span></h2><Link href="/explore" className="button button-lime">Find your next charger <ArrowUpRight size={17}/></Link></section>
  </main>;
}
