import type { Metadata } from "next";
import { ContactForm } from "@/components/contact-form";

export const metadata: Metadata = {
  title: "Contact support",
  description: "Contact VOLTARA about charger listings, bookings, account access, privacy, or safety concerns.",
  robots: { index: true, follow: true },
};

export default function ContactPage() {
  return <main className="plain-page contact-page">
    <div className="eyebrow"><span className="eyebrow-line"/> VOLTARA SUPPORT</div>
    <h1>How can we<br/><span>help?</span></h1>
    <p className="plain-lead">Send a question about a charger listing, booking, account, privacy, or safety. We’ll only confirm receipt after the request has been saved.</p>
    <section className="contact-panel">
      <ContactForm/>
      <aside className="contact-privacy-note"><b>How your message is handled</b><p>Your name, email, category, subject, and message are stored for support. The site uses a short-lived rate limit to reduce spam. Contact data is not visible to public users.</p><p>Email delivery depends on the support email service being configured for this site.</p></aside>
    </section>
  </main>;
}
