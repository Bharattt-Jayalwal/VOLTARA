import { redirect } from "next/navigation";
export default function HostSettingsPage(){redirect("/host");}
