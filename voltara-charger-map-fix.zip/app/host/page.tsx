import { HostClient } from "@/components/host-client";
export const metadata = { title: "Host workspace · VOLTARA" };
export default function HostPage() { return <HostClient/>; }
