import { redirect } from "next/navigation";
export default function HostAvailabilityPage(){redirect("/host");}
