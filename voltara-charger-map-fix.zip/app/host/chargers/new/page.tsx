import { redirect } from "next/navigation";
export default function NewChargerPage(){redirect("/host");}
