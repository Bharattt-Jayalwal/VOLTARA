import { redirect } from "next/navigation";
export default function HostChargersPage(){redirect("/host");}
