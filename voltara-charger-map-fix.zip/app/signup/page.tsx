import { Suspense } from "react";
import { AuthForm } from "@/components/auth-form";
export const metadata = { title: "Create account · VOLTARA" };
export default function SignupPage() { return <Suspense fallback={<main className="auth-loading">Loading account setup…</main>}><AuthForm mode="signup"/></Suspense>; }
