import { ExploreClient } from "@/components/explore-client";

export const metadata = { title: "Explore chargers · VOLTARA" };
export default function ExplorePage() { return <main><ExploreClient/></main>; }
