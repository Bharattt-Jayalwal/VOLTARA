import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";

const listingSchema = z.object({
  name: z.string().trim().min(2).max(120), description: z.string().max(3000).optional().default(""),
  address: z.string().max(240).optional().default(""), area: z.string().trim().min(2).max(120), countryCode: z.string().length(2).optional(),
  latitude: z.number().min(-90).max(90), longitude: z.number().min(-180).max(180), powerKw: z.number().positive().max(2000),
  kind: z.enum(["AC","DC"]), connector: z.enum(["NACS","CCS1","CCS2","Type 1","Type 2","CHAdeMO","GB/T","Other"]), pricePerKwh: z.number().min(0).optional(), currency: z.string().length(3).optional(),
  weekdays: z.array(z.number().int().min(0).max(6)).min(1).max(7), startTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/), endTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/), timezone: z.string().min(1).max(64),
});

export async function GET() {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data, error } = await supabase.from("chargers").select("id,name,description,locality,latitude,longitude,power_kw,charge_kind,access_type,host_verified,status,last_status_confirmed_at,price_per_kwh,currency,charger_connectors(connector_type)").eq("listing_status","approved").eq("is_listed",true).eq("demo",false);
  if (error) return NextResponse.json({ error: "Could not load charger listings." }, { status: 500 });
  return NextResponse.json({ chargers: data });
}

export async function POST(request: Request) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return NextResponse.json({ error: "Sign in before submitting a charger." }, { status: 401 });
  const parsed = listingSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Please check the charger and availability details.", fields: parsed.error.flatten().fieldErrors }, { status: 400 });
  const v = parsed.data;
  if (v.endTime <= v.startTime) return NextResponse.json({ error: "Availability end time must be after start time." }, { status: 400 });
  const { data, error } = await supabase.rpc("create_host_charger", { p_input: {
    name: v.name, description: v.description, address: v.address, locality: v.area, country_code: v.countryCode,
    latitude: v.latitude, longitude: v.longitude, power_kw: v.powerKw, charge_kind: v.kind, connector_type: v.connector,
    price_per_kwh: v.pricePerKwh, currency: v.currency || "USD", weekdays: v.weekdays, start_time: v.startTime, end_time: v.endTime, timezone: v.timezone,
  } });
  if (error) return NextResponse.json({ error: "The listing could not be submitted. Check the configured database migration and account permissions." }, { status: 400 });
  return NextResponse.json({ id: data, listingStatus: "pending" }, { status: 201 });
}
