import { NextResponse } from "next/server";
import { contactRequestSchema } from "@/lib/contact-schema";
import { createAdminClient } from "@/lib/supabase-admin";

export const runtime = "nodejs";

function json(body: unknown, status: number) {
  return NextResponse.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

async function hmac(value: string, secret: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const digest = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
  return Array.from(digest, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char] ?? char);
}

export async function POST(request: Request) {
  const requestOrigin = new URL(request.url).origin;
  const origin = request.headers.get("origin");
  if ((origin && origin !== requestOrigin) || request.headers.get("sec-fetch-site") === "cross-site") {
    return json({ error: "This request could not be verified. Reload the page and try again." }, 403);
  }

  if (!request.headers.get("content-type")?.toLowerCase().includes("application/json")) {
    return json({ error: "Submit the form using the contact page." }, 415);
  }
  const declaredSize = Number(request.headers.get("content-length") || 0);
  if (declaredSize > 12_000) return json({ error: "The message is too large." }, 413);
  const raw = await request.text();
  if (raw.length > 12_000) return json({ error: "The message is too large." }, 413);

  let body: unknown;
  try { body = JSON.parse(raw); } catch { return json({ error: "Enter the contact details and try again." }, 400); }
  const parsed = contactRequestSchema.safeParse(body);
  if (!parsed.success) return json({ error: "Check the name, email, category, subject, and message fields." }, 400);
  if (parsed.data.website.trim()) return json({ error: "This submission could not be accepted." }, 400);

  const admin = createAdminClient();
  const hashSecret = process.env.CONTACT_HASH_SECRET;
  if (!admin || !hashSecret || hashSecret.length < 32) {
    return json({ error: "Support requests are temporarily unavailable. Please try again later." }, 503);
  }

  const trustedIp = request.headers.get("x-vercel-forwarded-for")
    || request.headers.get("x-real-ip")
    || request.headers.get("x-forwarded-for")?.split(",")[0]?.trim()
    || "unavailable";
  const [ipHash, emailHash] = await Promise.all([
    hmac(`ip:${trustedIp}`, hashSecret),
    hmac(`email:${parsed.data.email}`, hashSecret),
  ]);
  const { data: requestId, error: persistError } = await admin.rpc("submit_contact_request", {
    p_name: parsed.data.name,
    p_email: parsed.data.email,
    p_category: parsed.data.category,
    p_subject: parsed.data.subject,
    p_message: parsed.data.message,
    p_ip_hash: ipHash,
    p_email_hash: emailHash,
  });
  if (persistError) {
    if (/rate limit/i.test(persistError.message)) return json({ error: "Please wait before sending another support request." }, 429);
    return json({ error: "We could not save your request. Please try again later." }, 503);
  }

  const resendKey = process.env.RESEND_API_KEY;
  const supportEmail = process.env.SUPPORT_EMAIL;
  const fromEmail = process.env.RESEND_FROM_EMAIL;
  let delivery: "sent" | "failed" | "not_configured" = "not_configured";
  if (resendKey && supportEmail && fromEmail) {
    const { name, email, category, subject, message } = parsed.data;
    try {
      const response = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: fromEmail,
          to: [supportEmail],
          reply_to: email,
          subject: `VOLTARA support: ${subject}`,
          text: `Name: ${name}\nEmail: ${email}\nCategory: ${category}\n\n${message}`,
          html: `<h2>VOLTARA support request</h2><p><b>Name:</b> ${escapeHtml(name)}</p><p><b>Email:</b> ${escapeHtml(email)}</p><p><b>Category:</b> ${escapeHtml(category)}</p><p><b>Subject:</b> ${escapeHtml(subject)}</p><p>${escapeHtml(message).replace(/\n/g, "<br>")}</p>`,
        }),
        signal: AbortSignal.timeout(8_000),
      });
      delivery = response.ok ? "sent" : "failed";
      if (!response.ok) console.error("VOLTARA support email delivery failed with HTTP status", response.status);
    } catch {
      delivery = "failed";
      console.error("VOLTARA support email delivery failed before confirmation");
    }
  }
  if (requestId) {
    const { error: updateError } = await admin.from("contact_requests").update({ email_delivery_status: delivery }).eq("id", requestId);
    if (updateError) console.error("VOLTARA support email status could not be saved");
  }

  const message = delivery === "sent"
    ? "Your request was saved and sent to the configured support address."
    : delivery === "failed"
      ? "Your request was saved, but support email delivery needs attention."
      : "Your request was saved. Support email delivery is not configured, so a reply may be delayed.";
  return json({ ok: true, message }, 201);
}
