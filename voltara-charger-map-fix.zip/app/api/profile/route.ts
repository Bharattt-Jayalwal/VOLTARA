import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";

const profileSchema = z.object({
  displayName: z.string().trim().min(2).max(80),
  phone: z.string().trim().max(32).nullable().optional(),
});

export async function GET() {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  const { data, error } = await supabase.from("profiles").select("display_name,phone").eq("id", user.id).maybeSingle();
  if (error) return NextResponse.json({ error: "Could not load profile details." }, { status: 500 });
  return NextResponse.json({ displayName: data?.display_name || user.user_metadata.display_name || "", phone: data?.phone || "" });
}

export async function PUT(request: Request) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  const parsed = profileSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Enter a valid display name and optional phone number." }, { status: 400 });
  const { displayName, phone } = parsed.data;
  const { error } = await supabase.from("profiles").upsert({ id: user.id, display_name: displayName, phone: phone || null }, { onConflict: "id" });
  if (error) return NextResponse.json({ error: "Could not save profile details." }, { status: 400 });
  return NextResponse.json({ displayName, phone: phone || "" });
}
