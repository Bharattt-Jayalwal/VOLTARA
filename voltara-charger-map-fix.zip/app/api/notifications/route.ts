import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";

const markReadSchema = z.object({ id: z.string().uuid() });

export async function GET(request: Request) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const url = new URL(request.url);
  const requestedLimit = Number(url.searchParams.get("limit") ?? 30);
  const limit = Number.isFinite(requestedLimit) ? Math.max(1, Math.min(100, Math.floor(requestedLimit))) : 30;
  const requestedOffset = Number(url.searchParams.get("offset") ?? 0);
  const offset = Number.isFinite(requestedOffset) ? Math.max(0, Math.min(10_000, Math.floor(requestedOffset))) : 0;

  const { data, error, count } = await supabase
    .from("notifications")
    .select("id,notification_type,title,body,related_id,read_at,created_at", { count: "exact" })
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .range(offset, offset + limit - 1);

  if (error) return NextResponse.json({ error: "Could not load notifications." }, { status: 500 });
  return NextResponse.json({ notifications: data ?? [], total: count ?? 0, limit, offset });
}

export async function PATCH(request: Request) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const parsed = markReadSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "A valid notification id is required." }, { status: 400 });

  const { error } = await supabase.rpc("mark_notification_read", { p_notification_id: parsed.data.id });
  if (error) return NextResponse.json({ error: "Could not mark this notification as read." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
