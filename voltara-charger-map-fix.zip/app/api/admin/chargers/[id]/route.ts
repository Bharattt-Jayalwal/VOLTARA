import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";
const schema=z.object({decision:z.enum(["approve","reject"])});
export async function PATCH(request:Request,{params}:{params:Promise<{id:string}>}){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
  const {id}=await params;const parsed=schema.safeParse(await request.json().catch(()=>null));if(!parsed.success)return NextResponse.json({error:"Choose approve or reject."},{status:400});
  const {error}=await supabase.rpc("review_charger",{p_charger_id:id,p_decision:parsed.data.decision});
  if(error)return NextResponse.json({error:"Administrative review was rejected by the database."},{status:403});
  return NextResponse.json({ok:true});
}
