import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase-server";

export async function GET() {
  const supabase=await createClient();
  if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();
  if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
  const {data:roles}=await supabase.from("user_roles").select("role").eq("user_id",user.id);
  if(!roles?.some(r=>r.role==="admin"))return NextResponse.json({error:"Administrator role required."},{status:403});
  const {data,error}=await supabase.from("chargers").select("id,name,description,latitude,longitude,power_kw,charge_kind,access_type,price_per_kwh,currency,status,last_status_confirmed_at,owner_id,charger_connectors(connector_type)").eq("listing_status","pending").eq("demo",false);
  if(error)return NextResponse.json({error:"Could not load the review queue."},{status:500});
  return NextResponse.json({chargers:data});
}
