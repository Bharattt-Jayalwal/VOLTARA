import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase-server";

async function adminClient() {
  const supabase = await createClient();
  if (!supabase) return { response: NextResponse.json({ error: "Supabase is not configured." }, { status: 503 }) };
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { response: NextResponse.json({ error: "Sign in required." }, { status: 401 }) };
  const { data: roles, error } = await supabase.from("user_roles").select("role").eq("user_id", user.id);
  if (error || !roles?.some((role) => role.role === "admin")) {
    return { response: NextResponse.json({ error: "Administrator role required." }, { status: 403 }) };
  }
  return { supabase };
}

export async function GET(request: Request) {
  const auth = await adminClient();
  if ("response" in auth) return auth.response;

  const status = new URL(request.url).searchParams.get("status");
  const allowedStatuses = ["open", "triaged", "resolved", "dismissed"] as const;
  if (status && !allowedStatuses.includes(status as (typeof allowedStatuses)[number])) {
    return NextResponse.json({ error: "Invalid report status filter." }, { status: 400 });
  }

  let query = auth.supabase
    .from("charger_reports")
    .select("id,charger_id,reporter_id,reason,description,status,created_at,updated_at,chargers(name,locality)")
    .order("created_at", { ascending: false })
    .limit(200);
  if (status) query = query.eq("status", status);
  const { data, error } = await query;
  if (error) return NextResponse.json({ error: "Could not load charger reports." }, { status: 500 });
  return NextResponse.json({ reports: data ?? [] });
}
