import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";

const schema = z.object({ status: z.enum(["triaged", "resolved", "dismissed"]) });

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  const { data: roles, error: roleError } = await supabase.from("user_roles").select("role").eq("user_id", user.id);
  if (roleError || !roles?.some((role) => role.role === "admin")) {
    return NextResponse.json({ error: "Administrator role required." }, { status: 403 });
  }

  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid report id." }, { status: 400 });
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Choose triaged, resolved, or dismissed." }, { status: 400 });

  const { error } = await supabase.rpc("triage_charger_report", { p_report_id: id, p_status: parsed.data.status });
  if (error) return NextResponse.json({ error: "This report could not be updated. It may already be closed." }, { status: 409 });
  return NextResponse.json({ ok: true, status: parsed.data.status });
}
