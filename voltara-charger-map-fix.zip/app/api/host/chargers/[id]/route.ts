import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";

const schema = z.object({ isListed: z.boolean() }).strict();

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return NextResponse.json({ error: "Sign in to manage a charger listing." }, { status: 401 });
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Choose whether to pause or resume this listing." }, { status: 400 });
  const { id } = await params;
  const { error } = await supabase.rpc("set_host_charger_visibility", { p_charger_id: id, p_visible: parsed.data.isListed });
  if (error) return NextResponse.json({ error: "The listing could not be changed. It must be approved and belong to your account." }, { status: 403 });
  return NextResponse.json({ ok: true, isListed: parsed.data.isListed });
}
