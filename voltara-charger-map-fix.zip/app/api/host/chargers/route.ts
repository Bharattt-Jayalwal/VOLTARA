import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase-server";
export async function GET(){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
  const {data,error}=await supabase.from("chargers").select("id,name,description,locality,latitude,longitude,power_kw,charge_kind,access_type,host_verified,status,last_status_confirmed_at,price_per_kwh,currency,listing_status,is_listed,availability_rules(weekday,start_time,end_time,enabled),charger_connectors(connector_type)").eq("owner_id",user.id);
  if(error)return NextResponse.json({error:"Could not load host listings."},{status:500});
  return NextResponse.json({chargers:data});
}
