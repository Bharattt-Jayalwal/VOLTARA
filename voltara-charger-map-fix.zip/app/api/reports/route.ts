import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";
const schema=z.object({chargerId:z.string().uuid(),reason:z.enum(["unavailable","connector_incorrect","access_issue","price_incorrect","safety","other"]),description:z.string().max(2000).optional()});
export async function POST(request:Request){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in to send a report."},{status:401});
  const parsed=schema.safeParse(await request.json().catch(()=>null));if(!parsed.success)return NextResponse.json({error:"Choose a valid report reason."},{status:400});
  const {error}=await supabase.from("charger_reports").insert({charger_id:parsed.data.chargerId,reporter_id:user.id,reason:parsed.data.reason,description:parsed.data.description||""});
  if(error)return NextResponse.json({error:"Could not save this report."},{status:400});
  return NextResponse.json({ok:true},{status:201});
}
