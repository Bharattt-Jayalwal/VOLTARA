import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";
const schema=z.object({status:z.enum(["confirmed","rejected"])});
export async function PATCH(request:Request,{params}:{params:Promise<{id:string}>}){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
  const parsed=schema.safeParse(await request.json().catch(()=>null));if(!parsed.success)return NextResponse.json({error:"Invalid booking response."},{status:400});
  const {id}=await params;const {error}=await supabase.rpc("respond_to_booking",{p_booking_id:id,p_decision:parsed.data.status});
  if(error)return NextResponse.json({error:"The booking response was rejected by the database."},{status:403});
  return NextResponse.json({ok:true});
}
export async function DELETE(_request:Request,{params}:{params:Promise<{id:string}>}){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
  const {id}=await params;const {error}=await supabase.rpc("cancel_booking",{p_booking_id:id});
  if(error)return NextResponse.json({error:"The booking could not be cancelled."},{status:403});
  return NextResponse.json({ok:true});
}
