import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";

const schema=z.object({chargerId:z.string().uuid(),startsAt:z.string().datetime(),endsAt:z.string().datetime()});
export async function GET(){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
  const {data,error}=await supabase.from("bookings").select("id,charger_id,driver_id,starts_at,ends_at,status,chargers(name,owner_id)").order("starts_at",{ascending:false}).limit(100);
  if(error)return NextResponse.json({error:"Could not load bookings."},{status:500});
  return NextResponse.json({bookings:data});
}
export async function POST(request:Request){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in to request a booking."},{status:401});
  const parsed=schema.safeParse(await request.json().catch(()=>null));if(!parsed.success)return NextResponse.json({error:"Choose a valid charger and future time range."},{status:400});
  const v=parsed.data;if(Date.parse(v.startsAt)<=Date.now()||Date.parse(v.endsAt)<=Date.parse(v.startsAt))return NextResponse.json({error:"Booking times must be in the future and end after they start."},{status:400});
  const {data,error}=await supabase.rpc("create_booking_request",{p_charger_id:v.chargerId,p_starts_at:v.startsAt,p_ends_at:v.endsAt});
  if(error){const conflict=/overlap|availability|bookable/i.test(error.message);return NextResponse.json({error:conflict?error.message:"The booking request was rejected. Confirm the listing is approved and the time is available."},{status:conflict?409:400});}
  return NextResponse.json({id:data,status:"pending"},{status:201});
}
