import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";
const schema=z.object({chargerId:z.string().uuid(),favorite:z.boolean()});
export async function GET(){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
  const {data,error}=await supabase.from("favorites").select("charger_id").eq("user_id",user.id);
  if(error)return NextResponse.json({error:"Could not load saved chargers."},{status:500});
  return NextResponse.json({ids:(data||[]).map(row=>row.charger_id)});
}
export async function POST(request:Request){
  const supabase=await createClient();if(!supabase)return NextResponse.json({error:"Supabase is not configured."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
  const parsed=schema.safeParse(await request.json().catch(()=>null));if(!parsed.success)return NextResponse.json({error:"Invalid favorite request."},{status:400});
  const query=supabase.from("favorites");const result=parsed.data.favorite?await query.upsert({user_id:user.id,charger_id:parsed.data.chargerId}):await query.delete().eq("user_id",user.id).eq("charger_id",parsed.data.chargerId);
  if(result.error)return NextResponse.json({error:"Could not update saved chargers."},{status:400});
  return NextResponse.json({ok:true});
}
