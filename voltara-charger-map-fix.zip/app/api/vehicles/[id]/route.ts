import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase-server";

const vehicleUpdateSchema = z.object({
  make: z.string().trim().min(1).max(80).optional(),
  model: z.string().trim().min(1).max(80).optional(),
  variant: z.string().trim().max(80).nullable().optional(),
  modelYear: z.number().int().min(1980).max(2100).nullable().optional(),
  connectorTypes: z.array(z.string().trim().min(1).max(30)).max(8).optional(),
  batteryKwh: z.number().positive().max(300).nullable().optional(),
  maxChargeKw: z.number().positive().max(2000).nullable().optional(),
}).refine((value) => Object.keys(value).length > 0, { message: "At least one vehicle field is required." });

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid vehicle id." }, { status: 400 });
  const parsed = vehicleUpdateSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Check the vehicle details." }, { status: 400 });

  const v = parsed.data;
  const updates = {
    ...(v.make !== undefined ? { make: v.make } : {}),
    ...(v.model !== undefined ? { model: v.model } : {}),
    ...(v.variant !== undefined ? { variant: v.variant } : {}),
    ...(v.modelYear !== undefined ? { model_year: v.modelYear } : {}),
    ...(v.connectorTypes !== undefined ? { connector_types: v.connectorTypes } : {}),
    ...(v.batteryKwh !== undefined ? { battery_kwh: v.batteryKwh } : {}),
    ...(v.maxChargeKw !== undefined ? { max_charge_kw: v.maxChargeKw } : {}),
  };
  const { data, error } = await supabase.from("vehicles").update(updates).eq("id", id).eq("user_id", user.id).select("id").maybeSingle();
  if (error) return NextResponse.json({ error: "Could not update this vehicle." }, { status: 400 });
  if (!data) return NextResponse.json({ error: "Vehicle not found." }, { status: 404 });
  return NextResponse.json({ ok: true, id: data.id });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient();
  if (!supabase) return NextResponse.json({ error: "Supabase is not configured." }, { status: 503 });

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid vehicle id." }, { status: 400 });
  const { data, error } = await supabase.from("vehicles").delete().eq("id", id).eq("user_id", user.id).select("id").maybeSingle();
  if (error) return NextResponse.json({ error: "Could not delete this vehicle." }, { status: 400 });
  if (!data) return NextResponse.json({ error: "Vehicle not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
