import { NewPasswordForm } from "@/components/new-password-form";
export const metadata={title:"Set a new password · VOLTARA"};
export default function ResetPasswordPage(){return <NewPasswordForm/>;}
