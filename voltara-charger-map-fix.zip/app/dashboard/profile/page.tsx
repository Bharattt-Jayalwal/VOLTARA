import { ProfileClient } from "@/components/profile-client";
export const metadata = { title: "Profile settings · VOLTARA" };
export default function DriverProfilePage(){return <ProfileClient/>;}
