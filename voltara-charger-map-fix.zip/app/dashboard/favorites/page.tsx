import { redirect } from "next/navigation";
export default function DriverFavoritesPage(){redirect("/dashboard");}
