import { redirect } from "next/navigation";
export default function DriverVehiclesPage(){redirect("/dashboard");}
