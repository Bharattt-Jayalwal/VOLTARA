import { DashboardClient } from "@/components/dashboard-client";
export const metadata = { title: "Driver dashboard · VOLTARA" };
export default function DashboardPage() { return <DashboardClient/>; }
