import type { Metadata } from "next";
import Link from "next/link";
import { Header } from "@/components/header";
import { StoreProvider } from "@/components/store";
import { isDemoMode, isSupabaseConfigured } from "@/lib/runtime-mode";
import "./globals.css";
import "./features.css";
import "./overrides.css";

export const metadata: Metadata = {
  ...(process.env.NEXT_PUBLIC_SITE_URL ? { metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL) } : {}),
  title: { default: "VOLTARA — Find it. Trust it. Charge.", template: "%s | VOLTARA" },
  description: "Discover compatible EV charging with clearer reliability signals and host-shared reservations.",
  openGraph: {
    type: "website",
    siteName: "VOLTARA",
    title: "VOLTARA — Find it. Trust it. Charge.",
    description: "Discover compatible EV charging with clearer reliability signals and host-shared reservations.",
  },
  twitter: { card: "summary_large_image", title: "VOLTARA — Find it. Trust it. Charge.", description: "Discover compatible EV charging with clearer reliability signals and host-shared reservations." },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><StoreProvider><Header/>{children}<footer className="site-footer"><div className="footer-top"><div><Link className="brand footer-brand" href="/"><span className="brand-mark">⚡</span><span>VOLTARA</span></Link><p>Find it. Trust it. Charge.</p></div><div className="footer-links"><Link href="/explore">Explore</Link><Link href="/host">For hosts</Link><Link href="/how-it-works">How it works</Link><Link href="/about">About</Link><Link href="/contact">Contact</Link><Link href="/privacy">Privacy</Link><Link href="/terms">Terms</Link></div><div className="footer-status"><span className="pulse-dot"/> {isDemoMode ? "Prototype · demo data" : isSupabaseConfigured ? "Host-submitted directory" : "Service setup required"}</div></div><div className="footer-bottom"><span>© 2026 VOLTARA</span><span>We’ll show you what we know, and when we last knew it.</span></div></footer></StoreProvider></body></html>;
}
