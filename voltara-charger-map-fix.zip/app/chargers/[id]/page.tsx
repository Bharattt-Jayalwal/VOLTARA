import { cache } from "react";
import type { Metadata } from "next";
import { ChargerDetail } from "@/components/charger-detail";
import { demoChargers, type Charger } from "@/lib/chargers";
import { createClient } from "@/lib/supabase-server";
import { isDemoMode } from "@/lib/runtime-mode";
import { ServiceUnavailable } from "@/components/service-unavailable";

const getPublicCharger = cache(async (id: string) => {
  const supabase = await createClient();
  if (!supabase) return null;
  const { data } = await supabase
    .from("chargers")
    .select("id,name,description,locality,latitude,longitude,power_kw,charge_kind,access_type,host_verified,status,last_status_confirmed_at,price_per_kwh,currency,listing_status,is_listed,demo,charger_connectors(connector_type)")
    .eq("id", id)
    .eq("demo", false)
    .maybeSingle();
  if (!data || data.listing_status !== "approved" || !data.is_listed) return null;
  return data;
});

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  if (isDemoMode) {
    const demo = demoChargers.find((charger) => charger.id === id);
    if (demo) return { title: `${demo.name} · Demo charger`, robots: { index: false, follow: false } };
  }
  const data = await getPublicCharger(id);
  if (!data) return { title: "Charger listing unavailable", robots: { index: false, follow: false } };
  return {
    title: data.name,
    description: `${data.power_kw} kW ${data.charge_kind} charger, ${data.access_type} access. Host-submitted listing; availability is not independently monitored.`,
    robots: { index: true, follow: true },
    openGraph: { title: `${data.name} · VOLTARA`, description: `${data.power_kw} kW ${data.charge_kind} charger with host-submitted listing information.` },
  };
}

export default async function ChargerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (isDemoMode) {
    const demo = demoChargers.find((charger) => charger.id === id);
    if (demo) return <ChargerDetail charger={demo} id={id}/>;
    if (id.startsWith("host-") || id.startsWith("demo-")) return <ChargerDetail charger={undefined} id={id}/>;
  }
  const data = await getPublicCharger(id);
  if (!data) {
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !(process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)) {
      return <ServiceUnavailable feature="Charger details"/>;
    }
    return <ChargerDetail charger={undefined} id={id}/>;
  }
  const charger: Charger = {
    id: data.id,
    name: data.name,
    area: data.locality || "Host supplied location",
    latitude: Number(data.latitude),
    longitude: Number(data.longitude),
    powerKw: Number(data.power_kw),
    kind: data.charge_kind as Charger["kind"],
    connector: ((data.charger_connectors?.[0]?.connector_type || "Other") as Charger["connector"]),
    pricePerKwh: data.price_per_kwh === null ? null : Number(data.price_per_kwh),
    currency: data.currency?.trim() || "",
    access: data.access_type === "shared" ? "Shared" : "Public",
    hostVerified: data.host_verified,
    status: (data.status || "unknown") as Charger["status"],
    lastConfirmedAt: data.last_status_confirmed_at,
    demo: false,
    listedBy: "Host-submitted",
    description: data.description || "Host-submitted charger listing.",
  };
  return <ChargerDetail charger={charger} id={id}/>;
}
