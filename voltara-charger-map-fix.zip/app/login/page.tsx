import { Suspense } from "react";
import { AuthForm } from "@/components/auth-form";
export const metadata = { title: "Sign in · VOLTARA" };
export default function LoginPage() { return <Suspense fallback={<main className="auth-loading">Loading sign in…</main>}><AuthForm mode="login"/></Suspense>; }
