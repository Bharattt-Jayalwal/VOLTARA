import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase-server";

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url);
  const callbackError = requestUrl.searchParams.get("error");
  const code = requestUrl.searchParams.get("code");
  const supabase = await createClient();

  if (callbackError || !code || !supabase) {
    return NextResponse.redirect(new URL("/login?error=auth_callback_failed", requestUrl.origin));
  }

  const { error } = await supabase.auth.exchangeCodeForSession(code);
  if (error) {
    return NextResponse.redirect(new URL("/login?error=auth_callback_failed", requestUrl.origin));
  }

  const requestedNext = requestUrl.searchParams.get("next") || "/dashboard";
  const destination = new URL(requestedNext, requestUrl.origin);
  const safeDestination = destination.origin === requestUrl.origin ? destination : new URL("/dashboard", requestUrl.origin);
  return NextResponse.redirect(safeDestination);
}
