import type { MetadataRoute } from "next";

function siteOrigin() {
  try {
    const configured = process.env.NEXT_PUBLIC_SITE_URL;
    return configured ? new URL(configured).origin : null;
  } catch {
    return null;
  }
}

export default function robots(): MetadataRoute.Robots {
  const origin = siteOrigin();
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/admin/", "/dashboard/", "/host/", "/login/", "/signup/", "/forgot-password/", "/reset-password/", "/api/"],
    },
    ...(origin ? { sitemap: `${origin}/sitemap.xml` } : {}),
  };
}
