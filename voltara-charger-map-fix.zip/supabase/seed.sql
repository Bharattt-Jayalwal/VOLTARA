-- Local/demo seed only. Never apply this file to a production data project.
insert into public.chargers
  (name,description,locality,country_code,latitude,longitude,power_kw,charge_kind,access_type,listing_status,is_listed,host_verified,status,status_source,last_status_confirmed_at,source_provider,source_record_id,price_per_kwh,demo)
values
  ('Demo Loop Fast Charge 01','Fictional charger for local development. Not a real location or live network station.','VOLTARA Brooklyn Demo Loop','US',40.7068,-73.9859,150,'DC','public','approved',true,true,'unknown','seed_simulation',null,'voltara_demo','demo-01',0.420,true),
  ('Demo Loop Shared Drive 02','Fictional host-shared charger for local development.','VOLTARA Brooklyn Demo Loop','US',40.7145,-73.9992,11,'AC','shared','approved',true,true,'unknown','seed_simulation',null,'voltara_demo','demo-02',0.290,true),
  ('Demo Loop Fast Charge 03','Fictional charger for local development. Not a real location or live network station.','VOLTARA Brooklyn Demo Loop','US',40.7012,-73.9721,50,'DC','public','approved',true,false,'unknown','seed_simulation',null,'voltara_demo','demo-03',0.380,true)
on conflict(source_provider,source_record_id) do nothing;

insert into public.charger_connectors(charger_id,connector_type,max_power_kw)
select c.id,x.connector_type,x.power_kw from public.chargers c
join (values ('demo-01','NACS',150::numeric),('demo-02','Type 2',11::numeric),('demo-03','CCS2',50::numeric)) as x(source_record_id,connector_type,power_kw)
on c.source_provider='voltara_demo' and c.source_record_id=x.source_record_id
on conflict(charger_id,connector_type) do nothing;
