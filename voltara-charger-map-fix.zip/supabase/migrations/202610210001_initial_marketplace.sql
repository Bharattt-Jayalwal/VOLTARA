-- VOLTARA marketplace schema. Apply with `supabase db push` to a configured project.
create extension if not exists pgcrypto;
create extension if not exists btree_gist;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  phone text,
  avatar_path text,
  country_code text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('driver','host','admin')),
  granted_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique(user_id, role)
);
create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  make text not null,
  model text not null,
  variant text,
  model_year int check (model_year between 1980 and 2100),
  connector_types text[] not null default '{}',
  battery_kwh numeric(7,2) check (battery_kwh > 0),
  max_charge_kw numeric(7,2) check (max_charge_kw > 0),
  entered_by_user boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.chargers (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete set null,
  name text not null check (length(name) between 2 and 120),
  description text,
  address text,
  locality text,
  country_code text,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  power_kw numeric(7,2) not null check (power_kw > 0 and power_kw <= 2000),
  charge_kind text not null check (charge_kind in ('AC','DC')),
  access_type text not null default 'shared' check (access_type in ('public','shared')),
  listing_status text not null default 'pending' check (listing_status in ('pending','approved','rejected','paused')),
  is_listed boolean not null default false,
  host_verified boolean not null default false,
  status text not null default 'unknown' check (status in ('available','unavailable','unknown','maintenance')),
  status_source text,
  last_status_confirmed_at timestamptz,
  source_provider text not null default 'private_host',
  source_record_id text,
  price_per_kwh numeric(8,3) check (price_per_kwh >= 0),
  currency char(3) not null default 'USD',
  parking_accessible boolean,
  demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(source_provider, source_record_id)
);
create index chargers_geo_idx on public.chargers (latitude, longitude) where listing_status='approved' and is_listed;
create index chargers_owner_idx on public.chargers(owner_id, created_at desc);
create index chargers_status_idx on public.chargers(status, last_status_confirmed_at desc);

create table public.charger_connectors (
  id uuid primary key default gen_random_uuid(),
  charger_id uuid not null references public.chargers(id) on delete cascade,
  connector_type text not null check (connector_type in ('NACS','CCS1','CCS2','Type 1','Type 2','CHAdeMO','GB/T','Other')),
  quantity int not null default 1 check (quantity between 1 and 100),
  max_power_kw numeric(7,2) check (max_power_kw > 0),
  created_at timestamptz not null default now(),
  unique(charger_id, connector_type)
);
create table public.charger_images (
  id uuid primary key default gen_random_uuid(),
  charger_id uuid not null references public.chargers(id) on delete cascade,
  storage_path text not null,
  caption text,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  unique(storage_path)
);
create table public.charger_sources (
  id uuid primary key default gen_random_uuid(),
  charger_id uuid not null references public.chargers(id) on delete cascade,
  provider text not null,
  provider_record_id text,
  capabilities jsonb not null default '{}'::jsonb,
  attribution text,
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  unique(provider, provider_record_id)
);
create table public.availability_rules (
  id uuid primary key default gen_random_uuid(),
  charger_id uuid not null references public.chargers(id) on delete cascade,
  weekday int not null check (weekday between 0 and 6),
  start_time time not null,
  end_time time not null,
  timezone text not null,
  valid_from date,
  valid_until date,
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  check (end_time > start_time)
);
create index availability_rules_charger_idx on public.availability_rules(charger_id, weekday) where enabled;
create table public.availability_exceptions (
  id uuid primary key default gen_random_uuid(),
  charger_id uuid not null references public.chargers(id) on delete cascade,
  exception_date date not null,
  start_time time,
  end_time time,
  is_unavailable boolean not null default true,
  note text,
  created_at timestamptz not null default now(),
  unique(charger_id, exception_date, start_time)
);
create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  charger_id uuid not null references public.chargers(id) on delete restrict,
  driver_id uuid not null references auth.users(id) on delete restrict,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending','confirmed','rejected','cancelled','in_progress','completed','failed','expired')),
  price_per_kwh numeric(8,3),
  currency char(3) not null default 'USD',
  cancellation_reason text,
  failure_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at > starts_at),
  check (ends_at - starts_at <= interval '12 hours'),
  exclude using gist (charger_id with =, tstzrange(starts_at, ends_at, '[)') with &&)
    where (status in ('pending','confirmed','in_progress'))
);
create index bookings_driver_idx on public.bookings(driver_id, starts_at desc);
create index bookings_charger_idx on public.bookings(charger_id, starts_at desc);
create table public.booking_events (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id) on delete restrict,
  driver_id uuid not null references auth.users(id) on delete restrict,
  provider text,
  provider_reference text unique,
  status text not null default 'not_configured' check (status in ('not_configured','pending','authorized','captured','failed','refunded','cancelled')),
  amount_minor bigint check (amount_minor >= 0),
  currency char(3) not null default 'USD',
  idempotency_key text unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id) on delete restrict,
  charger_id uuid not null references public.chargers(id) on delete cascade,
  driver_id uuid not null references auth.users(id) on delete cascade,
  rating int not null check (rating between 1 and 5),
  body text check (length(body) <= 2000),
  created_at timestamptz not null default now()
);
create table public.charger_reports (
  id uuid primary key default gen_random_uuid(),
  charger_id uuid not null references public.chargers(id) on delete cascade,
  reporter_id uuid references auth.users(id) on delete set null,
  reason text not null check (reason in ('unavailable','connector_incorrect','access_issue','price_incorrect','safety','other')),
  description text,
  status text not null default 'open' check (status in ('open','triaged','resolved','dismissed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.confidence_evidence (
  id uuid primary key default gen_random_uuid(),
  charger_id uuid not null references public.chargers(id) on delete cascade,
  evidence_type text not null check (evidence_type in ('successful_session','host_confirmation','operator_status','report','verification')),
  observed_at timestamptz not null,
  source text not null,
  verified boolean not null default false,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index confidence_evidence_recent_idx on public.confidence_evidence(charger_id, observed_at desc);
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  notification_type text not null,
  title text not null,
  body text not null,
  related_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);
create table public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  charger_id uuid not null references public.chargers(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, charger_id)
);
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_recent_idx on public.audit_logs(created_at desc);

create or replace function public.has_role(p_user uuid, p_role text)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.user_roles where user_id=p_user and role=p_role); $$;
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select public.has_role(auth.uid(),'admin'); $$;
revoke all on function public.has_role(uuid,text) from public;
grant execute on function public.has_role(uuid,text) to authenticated;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

create or replace function public.on_auth_user_created()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.profiles(id,display_name) values(new.id,coalesce(new.raw_user_meta_data->>'display_name','')) on conflict(id) do nothing;
  insert into public.user_roles(user_id,role) values(new.id,'driver') on conflict(user_id,role) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.on_auth_user_created();

create or replace function public.claim_host_role()
returns void language plpgsql security definer set search_path=public
as $$ begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  insert into public.user_roles(user_id,role) values(auth.uid(),'host') on conflict(user_id,role) do nothing;
end; $$;
revoke all on function public.claim_host_role() from public;
grant execute on function public.claim_host_role() to authenticated;

create or replace function public.create_host_charger(p_input jsonb)
returns uuid language plpgsql security definer set search_path=public
as $$
declare new_id uuid; day_value int; connector_value text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  perform public.claim_host_role();
  insert into public.chargers(owner_id,name,description,address,locality,country_code,latitude,longitude,power_kw,charge_kind,access_type,listing_status,is_listed,host_verified,source_provider,price_per_kwh,currency)
  values(auth.uid(),p_input->>'name',p_input->>'description',p_input->>'address',p_input->>'locality',p_input->>'country_code',
    (p_input->>'latitude')::double precision,(p_input->>'longitude')::double precision,(p_input->>'power_kw')::numeric,
    p_input->>'charge_kind','shared','pending',false,false,'private_host',nullif(p_input->>'price_per_kwh','')::numeric,coalesce(p_input->>'currency','USD'))
  returning id into new_id;
  connector_value:=p_input->>'connector_type';
  insert into public.charger_connectors(charger_id,connector_type,max_power_kw) values(new_id,connector_value,(p_input->>'power_kw')::numeric);
  for day_value in select jsonb_array_elements_text(p_input->'weekdays')::int loop
    insert into public.availability_rules(charger_id,weekday,start_time,end_time,timezone)
    values(new_id,day_value,(p_input->>'start_time')::time,(p_input->>'end_time')::time,coalesce(p_input->>'timezone','UTC'));
  end loop;
  insert into public.charger_sources(charger_id,provider,capabilities,attribution)
  values(new_id,'private_host',jsonb_build_object('booking_requests',true,'remote_start',false,'payment',false),'Host-submitted; pending manual review');
  return new_id;
end; $$;
revoke all on function public.create_host_charger(jsonb) from public;
grant execute on function public.create_host_charger(jsonb) to authenticated;

create or replace function public.create_booking_request(p_charger_id uuid, p_starts_at timestamptz, p_ends_at timestamptz)
returns uuid language plpgsql security definer set search_path=public
as $$
declare c public.chargers%rowtype; new_id uuid; allowed boolean;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_ends_at <= p_starts_at or p_starts_at <= now() or p_ends_at-p_starts_at > interval '12 hours' then raise exception 'Invalid booking times'; end if;
  select * into c from public.chargers where id=p_charger_id for update;
  if not found or c.listing_status<>'approved' or not c.is_listed then raise exception 'This listing is not currently bookable'; end if;
  if c.access_type<>'shared' then raise exception 'This provider does not support reservations'; end if;
  if c.owner_id=auth.uid() then raise exception 'Hosts cannot book their own charger'; end if;
  select exists(
    select 1 from public.availability_rules r
    where r.charger_id=c.id and r.enabled
      and (r.valid_from is null or (p_starts_at at time zone r.timezone)::date>=r.valid_from)
      and (r.valid_until is null or (p_ends_at at time zone r.timezone)::date<=r.valid_until)
      and extract(dow from (p_starts_at at time zone r.timezone))::int=r.weekday
      and (p_starts_at at time zone r.timezone)::time>=r.start_time
      and (p_ends_at at time zone r.timezone)::time<=r.end_time
      and not exists(select 1 from public.availability_exceptions x where x.charger_id=c.id and x.exception_date=(p_starts_at at time zone r.timezone)::date and x.is_unavailable)
  ) into allowed;
  if not allowed then raise exception 'The requested time is outside host availability'; end if;
  insert into public.bookings(charger_id,driver_id,starts_at,ends_at,status,price_per_kwh,currency)
  values(c.id,auth.uid(),p_starts_at,p_ends_at,'pending',c.price_per_kwh,c.currency) returning id into new_id;
  insert into public.booking_events(booking_id,actor_id,event_type) values(new_id,auth.uid(),'requested');
  insert into public.notifications(user_id,notification_type,title,body,related_id)
  values(c.owner_id,'booking_request','New booking request',c.name||' has a new reservation request.',new_id);
  return new_id;
exception when exclusion_violation then
  raise exception 'This time overlaps another pending or confirmed booking';
end; $$;
revoke all on function public.create_booking_request(uuid,timestamptz,timestamptz) from public;
grant execute on function public.create_booking_request(uuid,timestamptz,timestamptz) to authenticated;

create or replace function public.respond_to_booking(p_booking_id uuid, p_decision text)
returns void language plpgsql security definer set search_path=public
as $$
declare b public.bookings%rowtype; owner_id uuid; next_status text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_decision not in ('confirmed','rejected') then raise exception 'Invalid host decision'; end if;
  select * into b from public.bookings where id=p_booking_id for update;
  if not found then raise exception 'Booking not found'; end if;
  select c.owner_id into owner_id from public.chargers c where c.id=b.charger_id;
  if owner_id<>auth.uid() and not public.is_admin() then raise exception 'Not authorized to respond to this booking'; end if;
  if b.status<>'pending' then raise exception 'Booking is no longer pending'; end if;
  next_status:=p_decision;
  update public.bookings set status=next_status,updated_at=now() where id=b.id;
  insert into public.booking_events(booking_id,actor_id,event_type) values(b.id,auth.uid(),next_status);
  insert into public.notifications(user_id,notification_type,title,body,related_id)
  values(b.driver_id,'booking_'||next_status,'Booking '||next_status,'The host has '||next_status||' your request.',b.id);
end; $$;
revoke all on function public.respond_to_booking(uuid,text) from public;
grant execute on function public.respond_to_booking(uuid,text) to authenticated;

create or replace function public.cancel_booking(p_booking_id uuid)
returns void language plpgsql security definer set search_path=public
as $$ declare b public.bookings%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into b from public.bookings where id=p_booking_id for update;
  if not found or (b.driver_id<>auth.uid() and not public.is_admin()) then raise exception 'Not authorized to cancel this booking'; end if;
  if b.status not in ('pending','confirmed') then raise exception 'This booking cannot be cancelled'; end if;
  update public.bookings set status='cancelled',updated_at=now() where id=b.id;
  insert into public.booking_events(booking_id,actor_id,event_type) values(b.id,auth.uid(),'cancelled');
  insert into public.notifications(user_id,notification_type,title,body,related_id)
  select c.owner_id,'booking_cancelled','Booking cancelled','A driver cancelled a reservation request.',b.id from public.chargers c where c.id=b.charger_id;
end; $$;
revoke all on function public.cancel_booking(uuid) from public;
grant execute on function public.cancel_booking(uuid) to authenticated;

create or replace function public.review_charger(p_charger_id uuid,p_decision text)
returns void language plpgsql security definer set search_path=public
as $$ declare c public.chargers%rowtype;
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'Administrator role required'; end if;
  if p_decision not in ('approve','reject') then raise exception 'Invalid review decision'; end if;
  select * into c from public.chargers where id=p_charger_id for update;
  if not found then raise exception 'Charger not found'; end if;
  update public.chargers set listing_status=case when p_decision='approve' then 'approved' else 'rejected' end,
    is_listed=(p_decision='approve'),host_verified=(p_decision='approve'),updated_at=now() where id=c.id;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,details)
  values(auth.uid(),'charger_'||p_decision,'charger',c.id,jsonb_build_object('previous_status',c.listing_status));
  if c.owner_id is not null then insert into public.notifications(user_id,notification_type,title,body,related_id)
    values(c.owner_id,'charger_review','Listing '||p_decision,'Your charger listing was '||p_decision||' by the verification team.',c.id); end if;
end; $$;
revoke all on function public.review_charger(uuid,text) from public;
grant execute on function public.review_charger(uuid,text) to authenticated;

create or replace function public.updated_at_trigger()
returns trigger language plpgsql set search_path=public
as $$ begin new.updated_at=now(); return new; end; $$;
do $$ declare t text; begin
  foreach t in array array['profiles','vehicles','chargers','bookings','payments','charger_reports'] loop
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.updated_at_trigger()',t);
  end loop;
end; $$;

-- Enable RLS for every table exposed through Supabase's Data API.
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.vehicles enable row level security;
alter table public.chargers enable row level security;
alter table public.charger_connectors enable row level security;
alter table public.charger_images enable row level security;
alter table public.charger_sources enable row level security;
alter table public.availability_rules enable row level security;
alter table public.availability_exceptions enable row level security;
alter table public.bookings enable row level security;
alter table public.booking_events enable row level security;
alter table public.payments enable row level security;
alter table public.reviews enable row level security;
alter table public.charger_reports enable row level security;
alter table public.confidence_evidence enable row level security;
alter table public.notifications enable row level security;
alter table public.favorites enable row level security;
alter table public.audit_logs enable row level security;

create policy profiles_read_own on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
create policy profiles_insert_own on public.profiles for insert to authenticated with check(id=auth.uid());
create policy profiles_update_own on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy roles_read_own on public.user_roles for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy roles_insert_self_non_admin on public.user_roles for insert to authenticated with check(user_id=auth.uid() and role in ('driver','host'));
create policy vehicles_owner_all on public.vehicles for all to authenticated using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());
create policy chargers_public_or_owner_read on public.chargers for select to anon,authenticated using((listing_status='approved' and is_listed) or owner_id=auth.uid() or public.is_admin());
create policy chargers_host_insert on public.chargers for insert to authenticated with check(owner_id=auth.uid() and public.has_role(auth.uid(),'host') and listing_status='pending' and not is_listed);
create policy chargers_owner_update on public.chargers for update to authenticated using(owner_id=auth.uid() or public.is_admin()) with check((owner_id=auth.uid() and listing_status='pending' and not is_listed) or public.is_admin());
create policy connectors_public_or_owner_read on public.charger_connectors for select to anon,authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and ((c.listing_status='approved' and c.is_listed) or c.owner_id=auth.uid() or public.is_admin())));
create policy connectors_owner_write on public.charger_connectors for all to authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin()))) with check(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin())));
create policy images_public_or_owner_read on public.charger_images for select to anon,authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and ((c.listing_status='approved' and c.is_listed) or c.owner_id=auth.uid() or public.is_admin())));
create policy images_owner_write on public.charger_images for all to authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin()))) with check(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin())));
create policy sources_public_or_owner_read on public.charger_sources for select to anon,authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and ((c.listing_status='approved' and c.is_listed) or c.owner_id=auth.uid() or public.is_admin())));
create policy sources_owner_write on public.charger_sources for all to authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin()))) with check(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin())));
create policy availability_public_or_owner_read on public.availability_rules for select to anon,authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and ((c.listing_status='approved' and c.is_listed) or c.owner_id=auth.uid() or public.is_admin())));
create policy availability_owner_write on public.availability_rules for all to authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin()))) with check(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin())));
create policy exceptions_public_or_owner_read on public.availability_exceptions for select to anon,authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and ((c.listing_status='approved' and c.is_listed) or c.owner_id=auth.uid() or public.is_admin())));
create policy exceptions_owner_write on public.availability_exceptions for all to authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin()))) with check(exists(select 1 from public.chargers c where c.id=charger_id and (c.owner_id=auth.uid() or public.is_admin())));
create policy bookings_party_read on public.bookings for select to authenticated using(driver_id=auth.uid() or public.is_admin() or exists(select 1 from public.chargers c where c.id=charger_id and c.owner_id=auth.uid()));
create policy booking_events_party_read on public.booking_events for select to authenticated using(public.is_admin() or exists(select 1 from public.bookings b left join public.chargers c on c.id=b.charger_id where b.id=booking_id and (b.driver_id=auth.uid() or c.owner_id=auth.uid())));
create policy payments_owner_read on public.payments for select to authenticated using(driver_id=auth.uid() or public.is_admin());
create policy reviews_public_read on public.reviews for select to anon,authenticated using(true);
create policy reviews_driver_insert on public.reviews for insert to authenticated with check(driver_id=auth.uid() and exists(select 1 from public.bookings b where b.id=booking_id and b.driver_id=auth.uid() and b.status='completed' and b.charger_id=charger_id));
create policy reports_submit on public.charger_reports for insert to authenticated with check(reporter_id=auth.uid());
create policy reports_party_read on public.charger_reports for select to authenticated using(reporter_id=auth.uid() or public.is_admin() or exists(select 1 from public.chargers c where c.id=charger_id and c.owner_id=auth.uid()));
create policy reports_owner_update on public.charger_reports for update to authenticated using(public.is_admin() or exists(select 1 from public.chargers c where c.id=charger_id and c.owner_id=auth.uid())) with check(public.is_admin() or exists(select 1 from public.chargers c where c.id=charger_id and c.owner_id=auth.uid()));
create policy confidence_public_read on public.confidence_evidence for select to anon,authenticated using(exists(select 1 from public.chargers c where c.id=charger_id and c.listing_status='approved' and c.is_listed));
create policy confidence_owner_write on public.confidence_evidence for all to authenticated using(public.is_admin() or exists(select 1 from public.chargers c where c.id=charger_id and c.owner_id=auth.uid())) with check(public.is_admin() or exists(select 1 from public.chargers c where c.id=charger_id and c.owner_id=auth.uid()));
create policy notifications_owner_all on public.notifications for all to authenticated using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());
create policy favorites_owner_all on public.favorites for all to authenticated using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());
create policy audit_admin_read on public.audit_logs for select to authenticated using(public.is_admin());
