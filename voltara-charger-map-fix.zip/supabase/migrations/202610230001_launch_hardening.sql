-- Launch hardening for the existing marketplace schema.
-- Apply only after reviewing this migration against the target Supabase project.

-- A charger listing review does not verify a person's identity or establish live
-- charger telemetry. Keep the separate host_verified signal unchanged.
update public.chargers set host_verified=false where source_provider='private_host' and host_verified=true;
create or replace function public.review_charger(p_charger_id uuid,p_decision text)
returns void language plpgsql security definer set search_path=public
as $$ declare c public.chargers%rowtype;
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'Administrator role required'; end if;
  if p_decision not in ('approve','reject') then raise exception 'Invalid review decision'; end if;
  select * into c from public.chargers where id=p_charger_id for update;
  if not found or c.listing_status <> 'pending' then raise exception 'Pending charger listing not found'; end if;
  update public.chargers set
    listing_status=case when p_decision='approve' then 'approved' else 'rejected' end,
    is_listed=(p_decision='approve'),
    updated_at=now()
  where id=c.id;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,details)
  values(auth.uid(),'charger_'||p_decision,'charger',c.id,jsonb_build_object('previous_status',c.listing_status));
  if c.owner_id is not null then
    insert into public.notifications(user_id,notification_type,title,body,related_id)
    values(c.owner_id,'charger_review','Listing '||p_decision,'Your charger listing was '||p_decision||' after administrative review.',c.id);
  end if;
end; $$;
revoke all on function public.review_charger(uuid,text) from public;
grant execute on function public.review_charger(uuid,text) to authenticated;

-- A request must fit entirely inside one host-local availability day. The
-- original check could accept a booking that crossed midnight.
create or replace function public.create_booking_request(p_charger_id uuid, p_starts_at timestamptz, p_ends_at timestamptz)
returns uuid language plpgsql security definer set search_path=public
as $$
declare c public.chargers%rowtype; new_id uuid; allowed boolean;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_ends_at <= p_starts_at or p_starts_at <= now() or p_ends_at-p_starts_at > interval '12 hours' then raise exception 'Invalid booking times'; end if;
  select * into c from public.chargers where id=p_charger_id for update;
  if not found or c.listing_status<>'approved' or not c.is_listed or c.demo then raise exception 'This listing is not currently bookable'; end if;
  if c.access_type<>'shared' or c.owner_id is null then raise exception 'This provider does not support reservations'; end if;
  if c.owner_id=auth.uid() then raise exception 'Hosts cannot book their own charger'; end if;
  select exists(
    select 1 from public.availability_rules r
    where r.charger_id=c.id and r.enabled
      and (p_starts_at at time zone r.timezone)::date=(p_ends_at at time zone r.timezone)::date
      and (r.valid_from is null or (p_starts_at at time zone r.timezone)::date>=r.valid_from)
      and (r.valid_until is null or (p_ends_at at time zone r.timezone)::date<=r.valid_until)
      and extract(dow from (p_starts_at at time zone r.timezone))::int=r.weekday
      and (p_starts_at at time zone r.timezone)::time>=r.start_time
      and (p_ends_at at time zone r.timezone)::time<=r.end_time
      and not exists(
        select 1 from public.availability_exceptions x
        where x.charger_id=c.id and x.exception_date=(p_starts_at at time zone r.timezone)::date and x.is_unavailable
          and (x.start_time is null or x.end_time is null
            or ((p_starts_at at time zone r.timezone)::time < x.end_time and (p_ends_at at time zone r.timezone)::time > x.start_time))
      )
  ) into allowed;
  if not allowed then raise exception 'The requested time is outside host availability'; end if;
  insert into public.bookings(charger_id,driver_id,starts_at,ends_at,status,price_per_kwh,currency)
  values(c.id,auth.uid(),p_starts_at,p_ends_at,'pending',c.price_per_kwh,c.currency) returning id into new_id;
  insert into public.booking_events(booking_id,actor_id,event_type) values(new_id,auth.uid(),'requested');
  insert into public.notifications(user_id,notification_type,title,body,related_id)
  values(c.owner_id,'booking_request','New booking request',c.name||' has a new reservation request.',new_id);
  return new_id;
exception when exclusion_violation then
  raise exception 'This time overlaps another pending or confirmed booking';
end; $$;
revoke all on function public.create_booking_request(uuid,timestamptz,timestamptz) from public;
grant execute on function public.create_booking_request(uuid,timestamptz,timestamptz) to authenticated;

-- Drivers may cancel only before the booking starts; this is the pilot's
-- explicit cancellation rule until a reviewed commercial policy is adopted.
create or replace function public.cancel_booking(p_booking_id uuid)
returns void language plpgsql security definer set search_path=public
as $$ declare b public.bookings%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into b from public.bookings where id=p_booking_id for update;
  if not found or (b.driver_id<>auth.uid() and not public.is_admin()) then raise exception 'Not authorized to cancel this booking'; end if;
  if b.status not in ('pending','confirmed') or b.starts_at <= now() then raise exception 'This booking can no longer be cancelled'; end if;
  update public.bookings set status='cancelled',updated_at=now() where id=b.id;
  insert into public.booking_events(booking_id,actor_id,event_type) values(b.id,auth.uid(),'cancelled');
  insert into public.notifications(user_id,notification_type,title,body,related_id)
  select c.owner_id,'booking_cancelled','Booking cancelled','A driver cancelled a reservation request.',b.id from public.chargers c where c.id=b.charger_id;
end; $$;
revoke all on function public.cancel_booking(uuid) from public;
grant execute on function public.cancel_booking(uuid) to authenticated;

-- A listing can be hidden and restored without changing its approval decision.
create or replace function public.set_host_charger_visibility(p_charger_id uuid,p_visible boolean)
returns void language plpgsql security definer set search_path=public
as $$ declare c public.chargers%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into c from public.chargers where id=p_charger_id for update;
  if not found or (c.owner_id<>auth.uid() and not public.is_admin()) then raise exception 'Not authorized to manage this listing'; end if;
  if c.listing_status<>'approved' then raise exception 'Only approved listings can be paused or resumed'; end if;
  update public.chargers set is_listed=p_visible,updated_at=now() where id=c.id;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,details)
  values(auth.uid(),case when p_visible then 'charger_resumed' else 'charger_paused' end,'charger',c.id,'{}'::jsonb);
end; $$;
revoke all on function public.set_host_charger_visibility(uuid,boolean) from public;
grant execute on function public.set_host_charger_visibility(uuid,boolean) to authenticated;

-- Keep host details, provider metadata, and trust evidence from being changed
-- through child-table policies after a listing has been approved.
drop policy if exists chargers_public_or_owner_read on public.chargers;
create policy chargers_public_or_owner_read on public.chargers for select to anon,authenticated
  using ((listing_status='approved' and is_listed and not demo) or owner_id=auth.uid() or public.is_admin());

-- Row-level policies decide which records may be seen; column grants also
-- prevent the public Data API from returning private host street addresses or
-- allowing direct client edits to verification and telemetry fields.
revoke select,insert,update,delete on public.chargers from anon,authenticated;
grant select (id,name,description,locality,country_code,latitude,longitude,power_kw,charge_kind,access_type,listing_status,is_listed,host_verified,status,status_source,last_status_confirmed_at,source_provider,price_per_kwh,currency,parking_accessible,demo,created_at,updated_at) on public.chargers to anon;
grant select (id,name,description,locality,country_code,latitude,longitude,power_kw,charge_kind,access_type,listing_status,is_listed,host_verified,status,status_source,last_status_confirmed_at,source_provider,source_record_id,price_per_kwh,currency,parking_accessible,demo,owner_id,created_at,updated_at) on public.chargers to authenticated;
grant update (name,description,address,locality,country_code,latitude,longitude,power_kw,charge_kind,access_type,price_per_kwh,currency,parking_accessible) on public.chargers to authenticated;
grant execute on function public.is_admin() to anon;

drop policy if exists connectors_public_or_owner_read on public.charger_connectors;
create policy connectors_public_or_owner_read on public.charger_connectors for select to anon,authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and (((c.listing_status='approved' and c.is_listed and not c.demo)) or c.owner_id=auth.uid() or public.is_admin())));
drop policy if exists connectors_owner_write on public.charger_connectors;
create policy connectors_owner_write on public.charger_connectors for all to authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and ((c.owner_id=auth.uid() and c.listing_status='pending' and not c.is_listed) or public.is_admin())))
  with check (exists(select 1 from public.chargers c where c.id=charger_id and ((c.owner_id=auth.uid() and c.listing_status='pending' and not c.is_listed) or public.is_admin())));
revoke insert,update,delete on public.charger_connectors from anon,authenticated;

drop policy if exists images_public_or_owner_read on public.charger_images;
create policy images_public_or_owner_read on public.charger_images for select to anon,authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and (((c.listing_status='approved' and c.is_listed and not c.demo)) or c.owner_id=auth.uid() or public.is_admin())));
drop policy if exists images_owner_write on public.charger_images;
create policy images_owner_write on public.charger_images for all to authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and ((c.owner_id=auth.uid() and c.listing_status='pending' and not c.is_listed) or public.is_admin())))
  with check (exists(select 1 from public.chargers c where c.id=charger_id and ((c.owner_id=auth.uid() and c.listing_status='pending' and not c.is_listed) or public.is_admin())));
revoke insert,update,delete on public.charger_images from anon,authenticated;

drop policy if exists sources_public_or_owner_read on public.charger_sources;
create policy sources_public_or_owner_read on public.charger_sources for select to anon,authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and (((c.listing_status='approved' and c.is_listed and not c.demo)) or c.owner_id=auth.uid() or public.is_admin())));
drop policy if exists sources_owner_write on public.charger_sources;
create policy sources_owner_write on public.charger_sources for all to authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and ((c.owner_id=auth.uid() and c.listing_status='pending' and not c.is_listed) or public.is_admin())))
  with check (exists(select 1 from public.chargers c where c.id=charger_id and ((c.owner_id=auth.uid() and c.listing_status='pending' and not c.is_listed) or public.is_admin())));
revoke insert,update,delete on public.charger_sources from anon,authenticated;

drop policy if exists availability_public_or_owner_read on public.availability_rules;
create policy availability_public_or_owner_read on public.availability_rules for select to anon,authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and (((c.listing_status='approved' and c.is_listed and not c.demo)) or c.owner_id=auth.uid() or public.is_admin())));
revoke insert,update,delete on public.availability_rules from anon,authenticated;
drop policy if exists exceptions_public_or_owner_read on public.availability_exceptions;
create policy exceptions_public_or_owner_read on public.availability_exceptions for select to anon,authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and (((c.listing_status='approved' and c.is_listed and not c.demo)) or c.owner_id=auth.uid() or public.is_admin())));
revoke insert,update,delete on public.availability_exceptions from anon,authenticated;

drop policy if exists confidence_public_read on public.confidence_evidence;
create policy confidence_public_read on public.confidence_evidence for select to anon,authenticated
  using (exists(select 1 from public.chargers c where c.id=charger_id and c.listing_status='approved' and c.is_listed and not c.demo));
drop policy if exists confidence_owner_write on public.confidence_evidence;
create policy confidence_admin_write on public.confidence_evidence for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
revoke insert,update,delete on public.confidence_evidence from anon,authenticated;

-- Notifications are created only by trusted database functions. Users may
-- read and mark their own notifications, but cannot forge or delete them.
drop policy if exists notifications_owner_all on public.notifications;
create policy notifications_read_own on public.notifications for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy notifications_update_own on public.notifications for update to authenticated
  using(user_id=auth.uid()) with check(user_id=auth.uid());
revoke insert,delete on public.notifications from anon,authenticated;
revoke update on public.notifications from anon,authenticated;
grant update (read_at) on public.notifications to authenticated;

create or replace function public.mark_notification_read(p_notification_id uuid)
returns void language plpgsql security definer set search_path=public
as $$ begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  update public.notifications set read_at=coalesce(read_at,now()) where id=p_notification_id and user_id=auth.uid();
  if not found then raise exception 'Notification not found'; end if;
end; $$;
revoke all on function public.mark_notification_read(uuid) from public;
grant execute on function public.mark_notification_read(uuid) to authenticated;

-- Charger reports have no public read/update path and receive a per-account
-- submission cap; admins can triage them using trusted privileged tooling.
drop policy if exists reports_owner_update on public.charger_reports;
create policy reports_admin_update on public.charger_reports for update to authenticated using(public.is_admin()) with check(public.is_admin());
create or replace function public.limit_charger_reports()
returns trigger language plpgsql security definer set search_path=public
as $$ declare recent_count integer;
begin
  if new.reporter_id is null then raise exception 'Authentication required'; end if;
  perform pg_advisory_xact_lock(hashtext('charger-report:'||new.reporter_id::text));
  select count(*) into recent_count from public.charger_reports
    where reporter_id=new.reporter_id and created_at > now()-interval '24 hours';
  if recent_count >= 10 then raise exception 'Report submission limit reached'; end if;
  return new;
end; $$;
drop trigger if exists charger_report_rate_limit on public.charger_reports;
create trigger charger_report_rate_limit before insert on public.charger_reports for each row execute function public.limit_charger_reports();

-- Persisted support requests. The table and rate-limit RPC are only accessible
-- to the server service-role client; browser clients get no direct grants.
create table if not exists public.contact_requests (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 2 and 100),
  email text not null check (length(email) between 3 and 254),
  category text not null check (category in ('general','charger_listing','booking_support','account_privacy','safety','other')),
  subject text not null check (length(subject) between 4 and 160),
  message text not null check (length(message) between 10 and 4000),
  status text not null default 'new' check (status in ('new','triaged','resolved')),
  ip_hash text not null check (ip_hash ~ '^[a-f0-9]{64}$'),
  email_hash text not null check (email_hash ~ '^[a-f0-9]{64}$'),
  email_delivery_status text not null default 'not_configured' check (email_delivery_status in ('not_configured','sent','failed')),
  created_at timestamptz not null default now()
);
create index if not exists contact_requests_email_created_idx on public.contact_requests(email_hash,created_at desc);
create index if not exists contact_requests_ip_created_idx on public.contact_requests(ip_hash,created_at desc);
alter table public.contact_requests enable row level security;
revoke all on public.contact_requests from public,anon,authenticated;
grant select,insert,update on public.contact_requests to service_role;
revoke all on function public.set_host_charger_visibility(uuid,boolean) from public;

create or replace function public.submit_contact_request(
  p_name text,p_email text,p_category text,p_subject text,p_message text,p_ip_hash text,p_email_hash text
) returns uuid language plpgsql security definer set search_path=public
as $$
declare new_id uuid; email_day_count integer; ip_hour_count integer; ip_day_count integer;
begin
  if p_name is null or length(btrim(p_name)) not between 2 and 100
    or p_email is null or length(btrim(p_email)) not between 3 and 254
    or position('@' in p_email)<2
    or p_category not in ('general','charger_listing','booking_support','account_privacy','safety','other')
    or p_subject is null or length(btrim(p_subject)) not between 4 and 160
    or p_message is null or length(btrim(p_message)) not between 10 and 4000
    or p_ip_hash !~ '^[a-f0-9]{64}$' or p_email_hash !~ '^[a-f0-9]{64}$' then
    raise exception 'Invalid contact request';
  end if;
  perform pg_advisory_xact_lock(hashtext('contact-email:'||p_email_hash));
  perform pg_advisory_xact_lock(hashtext('contact-ip:'||p_ip_hash));
  if exists(select 1 from public.contact_requests where email_hash=p_email_hash and created_at>now()-interval '15 minutes') then
    raise exception 'Contact request rate limit exceeded';
  end if;
  select count(*) into email_day_count from public.contact_requests where email_hash=p_email_hash and created_at>now()-interval '24 hours';
  select count(*) into ip_hour_count from public.contact_requests where ip_hash=p_ip_hash and created_at>now()-interval '1 hour';
  select count(*) into ip_day_count from public.contact_requests where ip_hash=p_ip_hash and created_at>now()-interval '24 hours';
  if email_day_count>=5 or ip_hour_count>=5 or ip_day_count>=20 then raise exception 'Contact request rate limit exceeded'; end if;
  insert into public.contact_requests(name,email,category,subject,message,ip_hash,email_hash)
    values(btrim(p_name),lower(btrim(p_email)),p_category,btrim(p_subject),btrim(p_message),p_ip_hash,p_email_hash)
    returning id into new_id;
  return new_id;
end; $$;
revoke all on function public.submit_contact_request(text,text,text,text,text,text,text) from public,anon,authenticated;
grant execute on function public.submit_contact_request(text,text,text,text,text,text,text) to service_role;

-- Admin identity checks should not disclose other users' roles to ordinary users.
create or replace function public.has_role(p_user uuid,p_role text)
returns boolean language sql stable security definer set search_path=public
as $$
  select exists(select 1 from public.user_roles where user_id=p_user and role=p_role)
    and (p_user=auth.uid() or exists(select 1 from public.user_roles where user_id=auth.uid() and role='admin'));
$$;
revoke all on function public.has_role(uuid,text) from public;
grant execute on function public.has_role(uuid,text) to authenticated;
