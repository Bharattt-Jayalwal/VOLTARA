-- Complete administrator report triage through an audited, role-checked RPC.
-- Browser clients cannot directly update charger report status.
drop policy if exists reports_admin_update on public.charger_reports;
revoke update on public.charger_reports from anon, authenticated;

create or replace function public.triage_charger_report(p_report_id uuid, p_status text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  report_row public.charger_reports%rowtype;
begin
  if auth.uid() is null or not public.is_admin() then
    raise exception 'Administrator role required';
  end if;
  if p_status not in ('triaged', 'resolved', 'dismissed') then
    raise exception 'Invalid report status';
  end if;

  select * into report_row
  from public.charger_reports
  where id = p_report_id
  for update;

  if not found then raise exception 'Report not found'; end if;
  if report_row.status in ('resolved', 'dismissed') then
    if report_row.status = p_status then return; end if;
    raise exception 'Closed report cannot be reopened';
  end if;

  update public.charger_reports
  set status = p_status, updated_at = now()
  where id = report_row.id;

  insert into public.audit_logs(actor_id, action, entity_type, entity_id, details)
  values (
    auth.uid(),
    'charger_report_' || p_status,
    'charger_report',
    report_row.id,
    jsonb_build_object('charger_id', report_row.charger_id, 'previous_status', report_row.status)
  );
end;
$$;

revoke all on function public.triage_charger_report(uuid, text) from public, anon;
grant execute on function public.triage_charger_report(uuid, text) to authenticated;
