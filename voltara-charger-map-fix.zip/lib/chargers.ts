export type Connector = "NACS" | "CCS2" | "Type 2" | "CHAdeMO";
export type Charger = {
  id: string;
  name: string;
  area: string;
  latitude: number;
  longitude: number;
  powerKw: number;
  kind: "AC" | "DC";
  connector: Connector;
  pricePerKwh: number | null;
  currency?: string;
  access: "Public" | "Shared";
  hostVerified: boolean;
  listedBy: string;
  description: string;
  lastConfirmedAt: string | null;
  status: "available" | "unknown" | "unavailable";
  demo: boolean;
  pending?: boolean;
  availabilityText?: string;
  availabilityRules?: { weekdays: number[]; startTime: string; endTime: string };
  paused?: boolean;
};

// Every bundled location is deliberately synthetic and clearly labeled as demo data.
export const demoChargers: Charger[] = [
  { id: "demo-01", name: "The Foundry — Demo", area: "Brooklyn Demo Loop", latitude: 40.7068, longitude: -73.9859, powerKw: 150, kind: "DC", connector: "NACS", pricePerKwh: 0.42, access: "Public", hostVerified: true, listedBy: "VOLTARA Demo Network", description: "Illustrative fast-charge listing with step-free access and a covered bay.", lastConfirmedAt: new Date(Date.now() - 4 * 60_000).toISOString(), status: "available", demo: true },
  { id: "demo-02", name: "Canal House — Demo", area: "Brooklyn Demo Loop", latitude: 40.7145, longitude: -73.9992, powerKw: 11, kind: "AC", connector: "Type 2", pricePerKwh: 0.29, access: "Shared", hostVerified: true, listedBy: "VOLTARA Demo Host", description: "Illustrative shared driveway charger. Access details appear after a host accepts a request.", lastConfirmedAt: new Date(Date.now() - 28 * 60_000).toISOString(), status: "unknown", demo: true },
  { id: "demo-03", name: "Pier 8 — Demo", area: "Brooklyn Demo Loop", latitude: 40.7012, longitude: -73.9721, powerKw: 50, kind: "DC", connector: "CCS2", pricePerKwh: 0.38, access: "Public", hostVerified: false, listedBy: "VOLTARA Demo Network", description: "Illustrative station. The live operating status is not connected in this demo.", lastConfirmedAt: null, status: "unknown", demo: true },
  { id: "demo-04", name: "Garden Court — Demo", area: "Brooklyn Demo Loop", latitude: 40.7227, longitude: -73.9862, powerKw: 7, kind: "AC", connector: "Type 2", pricePerKwh: 0.25, access: "Shared", hostVerified: true, listedBy: "VOLTARA Demo Host", description: "Illustrative host listing with reservation requests and a sample access guide.", lastConfirmedAt: new Date(Date.now() - 11 * 60_000).toISOString(), status: "available", demo: true },
  { id: "demo-05", name: "Mercer Garage — Demo", area: "Brooklyn Demo Loop", latitude: 40.7258, longitude: -73.9954, powerKw: 100, kind: "DC", connector: "CHAdeMO", pricePerKwh: 0.36, access: "Public", hostVerified: true, listedBy: "VOLTARA Demo Network", description: "Illustrative public charger. Verify connector and status directly before travel.", lastConfirmedAt: new Date(Date.now() - 2 * 60 * 60_000).toISOString(), status: "unavailable", demo: true },
];

export function formatChargePrice(pricePerKwh: number | null, currency = "USD"): string {
  if (pricePerKwh === null || !Number.isFinite(pricePerKwh)) return "Price not listed";
  try {
    return new Intl.NumberFormat(undefined, { style: "currency", currency: currency.trim() || "USD", currencyDisplay: "code" }).format(pricePerKwh);
  } catch {
    return `${currency.trim() || "Currency"} ${pricePerKwh.toFixed(2)}`;
  }
}

export type ConfidenceEvidence = { successfulSessions30d: number; reports30d: number; hostVerified: boolean; lastConfirmedAt: string | null };
export function confidenceScore(e: ConfidenceEvidence): number | null {
  if (!e.hostVerified && e.successfulSessions30d < 3) return null;
  const freshness = e.lastConfirmedAt ? Math.max(0, 28 - Math.floor((Date.now() - Date.parse(e.lastConfirmedAt)) / 3_600_000)) : 0;
  return Math.min(100, Math.max(0, (e.hostVerified ? 25 : 0) + Math.min(e.successfulSessions30d, 10) * 6 + freshness + Math.max(0, 20 - e.reports30d * 8)));
}

export function freshnessLabel(confirmedAt: string | null): string {
  if (!confirmedAt) return "No recent confirmation";
  const age = Math.max(0, Date.now() - Date.parse(confirmedAt));
  if (age < 60_000) return "Confirmed just now";
  if (age < 60 * 60_000) return `Confirmed ${Math.floor(age / 60_000)} min ago`;
  if (age < 24 * 60 * 60_000) return `Confirmed ${Math.floor(age / (60 * 60_000))} hr ago`;
  return "Confirmation is stale";
}

export function straightLineKm(a: [number, number], b: [number, number]): number {
  const rad = (n: number) => (n * Math.PI) / 180;
  const dLat = rad(b[0] - a[0]);
  const dLon = rad(b[1] - a[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}
