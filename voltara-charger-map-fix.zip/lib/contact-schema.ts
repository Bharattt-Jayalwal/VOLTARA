import { z } from "zod";

export const contactCategories = [
  "general",
  "charger_listing",
  "booking_support",
  "account_privacy",
  "safety",
  "other",
] as const;

export const contactRequestSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.email().trim().max(254).transform((value) => value.toLowerCase()),
  category: z.enum(contactCategories),
  subject: z.string().trim().min(4).max(160),
  message: z.string().trim().min(10).max(4000),
  website: z.string().max(200).optional().default(""),
}).strict();
