const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && supabaseKey);

// Browser-only demo data is available in local development. A production build
// must show an unavailable/empty state until its real database is configured.
export const isDemoMode = process.env.NODE_ENV !== "production" && !isSupabaseConfigured;
export const isProductionBackendUnavailable = process.env.NODE_ENV === "production" && !isSupabaseConfigured;
