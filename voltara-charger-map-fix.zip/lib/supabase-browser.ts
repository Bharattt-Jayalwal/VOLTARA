import { createBrowserClient } from "@supabase/ssr";
import { isSupabaseConfigured } from "@/lib/runtime-mode";

const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
export { isSupabaseConfigured };

export function createClient() {
  if (!isSupabaseConfigured) throw new Error("Supabase is not configured. Use the labeled demo mode or add the project URL and publishable key.");
  return createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, key!);
}
