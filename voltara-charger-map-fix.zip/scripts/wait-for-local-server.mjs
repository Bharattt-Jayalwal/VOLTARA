const url = "http://127.0.0.1:3000/";
const deadline = Date.now() + 120_000;

while (Date.now() < deadline) {
  try {
    const response = await fetch(url, { redirect: "manual", signal: AbortSignal.timeout(2_000) });
    if (response.ok) {
      console.log("VOLTARA is ready. Opening your browser...");
      process.exit(0);
    }
  } catch {
    // The Next.js dev server is still starting.
  }
  await new Promise((resolve) => setTimeout(resolve, 1_000));
}

console.error("Timed out waiting for VOLTARA at http://localhost:3000.");
process.exit(1);
