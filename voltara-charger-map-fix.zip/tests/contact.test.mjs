import test from "node:test";
import assert from "node:assert/strict";
import { contactRequestSchema } from "../lib/contact-schema.ts";

const validRequest = {
  name: "Driver Example",
  email: "DRIVER@example.com",
  category: "booking_support",
  subject: "Booking request question",
  message: "I need help understanding the request status in my account.",
  website: "",
};

test("contact request validation trims and normalizes the email", () => {
  const parsed = contactRequestSchema.safeParse(validRequest);
  assert.equal(parsed.success, true);
  if (parsed.success) assert.equal(parsed.data.email, "driver@example.com");
});

test("contact request validation rejects invalid categories, short messages and extra fields", () => {
  assert.equal(contactRequestSchema.safeParse({ ...validRequest, category: "payments" }).success, false);
  assert.equal(contactRequestSchema.safeParse({ ...validRequest, message: "Help" }).success, false);
  assert.equal(contactRequestSchema.safeParse({ ...validRequest, isAdmin: true }).success, false);
});
