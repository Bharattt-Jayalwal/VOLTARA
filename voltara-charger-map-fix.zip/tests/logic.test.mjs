import test from "node:test";
import assert from "node:assert/strict";
import { confidenceScore, formatChargePrice, freshnessLabel, straightLineKm } from "../lib/chargers.ts";

test("confidence stays hidden until verified or supported by at least three recent sessions", () => {
  assert.equal(confidenceScore({ successfulSessions30d: 2, reports30d: 0, hostVerified: false, lastConfirmedAt: new Date().toISOString() }), null);
  assert.notEqual(confidenceScore({ successfulSessions30d: 0, reports30d: 0, hostVerified: true, lastConfirmedAt: new Date().toISOString() }), null);
});

test("confidence estimate remains within the documented 0–100 range", () => {
  const score = confidenceScore({ successfulSessions30d: 100, reports30d: 0, hostVerified: true, lastConfirmedAt: new Date().toISOString() });
  assert.ok(score !== null && score >= 0 && score <= 100);
});

test("freshness marks a confirmation older than one day as stale", () => {
  const old = new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString();
  assert.equal(freshnessLabel(old), "Confirmation is stale");
  assert.equal(freshnessLabel(null), "No recent confirmation");
});

test("straight-line distance uses Earth distance in kilometers", () => {
  const km = straightLineKm([0, 0], [0, 1]);
  assert.ok(km > 111 && km < 112);
});

test("a missing price is never presented as a zero-price charger", () => {
  assert.equal(formatChargePrice(null, "INR"), "Price not listed");
  assert.match(formatChargePrice(12.5, "INR"), /INR/);
});
